export type WerewolfRole =
  | 'villager'
  | 'werewolf'
  | 'seer'
  | 'bodyguard'
  | 'witch'
  | 'hunter';

export type WerewolfFaction = 'village' | 'werewolf';

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  color: string;
  statusMessage?: string;
  joinedAt: number;
}

export type WerewolfActionType =
  | 'wolf_kill'
  | 'seer_inspect'
  | 'seer_check'
  | 'guard_protect'
  | 'witch_heal'
  | 'witch_save'
  | 'witch_poison'
  | 'witch_pass'
  | 'hunter_shot'
  | 'hunter_shoot'
  | 'vote_lynch'
  | 'day_vote';

export type WerewolfPhase =
  | 'lobby'
  | 'night'
  | 'day_discuss'
  | 'day_vote'
  | 'hunter_revenge'
  | 'game_over';

export interface WerewolfPlayer {
  id: string;
  name: string;
  avatar: string;
  color: string;
  isBot?: boolean;
  isAlive: boolean;
  role?: WerewolfRole; // Real role (hidden from unauthorized players by server)
  revealedRole?: WerewolfRole; // Revealed to everyone upon death or game over
  deathReason?: 'werewolf' | 'lynch' | 'witch_poison' | 'hunter_shot';
  deathRound?: number;
  votesReceived: number;
}

export interface WerewolfActionState {
  wolfTargetId?: string;
  seerTargetId?: string;
  seerResult?: {
    targetId: string;
    targetName: string;
    isWolf: boolean;
    role: WerewolfRole;
  };
  guardTargetId?: string;
  lastGuardedId?: string;
  witchSaved?: boolean;
  witchPoisonTargetId?: string;
  witchHasHealPotion: boolean;
  witchHasPoisonPotion: boolean;
  hunterTargetId?: string;
  dayVotes: Record<string, string>; // voterId -> targetPlayerId
}

export interface WerewolfNightSummary {
  round: number;
  killedByWolf?: string; // target ID
  savedByGuard?: boolean;
  savedByWitch?: boolean;
  poisonedByWitch?: string;
  finalDeaths: Array<{
    id: string;
    name: string;
    reason: 'werewolf' | 'witch_poison';
  }>;
}

export interface WerewolfLogEntry {
  id: string;
  round: number;
  phase: WerewolfPhase;
  timestamp: number;
  type: 'system' | 'kill' | 'lynch' | 'save' | 'seer' | 'hunter' | 'chat';
  content: string;
  isSecretWolf?: boolean;
  isSecretGhost?: boolean;
}

export interface WerewolfGameState {
  roomId: string;
  phase: WerewolfPhase;
  round: number; // Night 1, Day 1, Night 2, etc.
  players: WerewolfPlayer[];
  timerSeconds: number;
  timerTotal: number;
  actions: WerewolfActionState;
  nightPendingVictimId?: string; // Player targeted by wolves this night (visible to Witch)
  lastNightSummary?: WerewolfNightSummary;
  logs: WerewolfLogEntry[];
  winner?: WerewolfFaction;
  hostId: string;
  startedAt?: number;
  endedAt?: number;
}

// Client-safe representation received via WebSocket
export interface ClientWerewolfSync {
  phase: WerewolfPhase;
  nightSubPhase?: 'werewolf' | 'seer' | 'bodyguard' | 'witch' | 'all';
  round: number;
  players: (WerewolfPlayer & { isHunterRevengePending?: boolean })[];
  timerSeconds: number;
  timerTotal: number;
  narratorMessage?: string;
  myRole?: WerewolfRole;
  myFaction?: WerewolfFaction;
  isSeated: boolean;
  isHost: boolean;
  winner?: WerewolfFaction;
  seerHistory: Array<{
    targetId: string;
    targetName: string;
    isWolf: boolean;
    round: number;
  }>;
  logs: WerewolfLogEntry[];
  wolfVotes?: Record<string, string>;
  dayVotes?: Record<string, string>;
  nightPending?: {
    victimId?: string;
    victimName?: string;
  };
  witchPotions?: {
    hasHeal: boolean;
    hasPoison: boolean;
  };
  alliedWolves?: string[];
  gameState?: WerewolfGameState;
}

export type WerewolfClientSyncPayload = ClientWerewolfSync;

export interface WerewolfChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderColor: string;
  channel: 'village' | 'wolf' | 'ghost' | 'narrator';
  content: string;
  timestamp: number;
}

export interface DeductionNote {
  targetId: string;
  status: 'innocent' | 'suspect' | 'confirmed_wolf' | 'unknown';
  claimedRole?: WerewolfRole | 'unknown';
  notes: string;
  updatedAt: number;
}
