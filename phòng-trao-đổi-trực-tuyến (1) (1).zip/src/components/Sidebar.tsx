import React, { useState } from 'react';
import {
  MessageSquare,
  HelpCircle,
  Lightbulb,
  Coffee,
  Hash,
  Plus,
  Compass,
  X,
  Radio,
  Search,
  Settings,
  Moon,
} from 'lucide-react';
import type { Room, UserProfile } from '../types';

interface SidebarProps {
  rooms: Room[];
  currentRoomId: string;
  onSelectRoom: (roomId: string) => void;
  onOpenCreateRoom: () => void;
  currentUser: UserProfile;
  onOpenProfile: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  onlineCountByRoom?: Record<string, number>;
}

export function Sidebar({
  rooms,
  currentRoomId,
  onSelectRoom,
  onOpenCreateRoom,
  currentUser,
  onOpenProfile,
  isOpenMobile,
  onCloseMobile,
  onlineCountByRoom = {},
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const getRoomIcon = (iconName: string, isSelected: boolean) => {
    const className = `w-4 h-4 ${isSelected ? 'text-blue-600' : 'text-slate-500'}`;
    switch (iconName) {
      case 'moon':
        return <Moon className={className} />;
      case 'help-circle':
        return <HelpCircle className={className} />;
      case 'lightbulb':
        return <Lightbulb className={className} />;
      case 'coffee':
        return <Coffee className={className} />;
      case 'message-square':
        return <MessageSquare className={className} />;
      default:
        return <Hash className={className} />;
    }
  };

  const filteredRooms = rooms.filter((r) =>
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-30 md:hidden"
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand & Workspace Title */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-xs">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800 text-sm tracking-tight flex items-center gap-1.5">
                Phòng Trao Đổi
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">Trực tuyến nhiều người</p>
            </div>
          </div>

          <button
            onClick={onCloseMobile}
            className="md:hidden p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Room Search */}
        <div className="px-3 pt-3 pb-1">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Tìm phòng..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 hover:bg-slate-100/80 focus:bg-white text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
            />
          </div>
        </div>

        {/* Room List Header */}
        <div className="px-3 pt-3 pb-1 flex items-center justify-between">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Các Phòng Trao Đổi ({filteredRooms.length})
          </span>
          <button
            id="btn-sidebar-create-room"
            onClick={onOpenCreateRoom}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-0.5 hover:bg-blue-50 px-1.5 py-0.5 rounded transition"
            title="Tạo phòng trao đổi mới"
          >
            <Plus className="w-3.5 h-3.5" />
            Tạo phòng
          </button>
        </div>

        {/* Room List */}
        <div className="flex-1 overflow-y-auto px-2 py-1 space-y-0.5">
          {filteredRooms.map((room) => {
            const isSelected = room.id === currentRoomId;
            const count = onlineCountByRoom[room.id] || 0;

            return (
              <button
                key={room.id}
                id={`room-item-${room.id}`}
                onClick={() => {
                  onSelectRoom(room.id);
                  onCloseMobile();
                }}
                className={`w-full text-left px-3 py-2.5 rounded-xl transition flex items-center justify-between group ${
                  isSelected
                    ? 'bg-blue-50/80 text-blue-900 font-medium'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className={`p-1.5 rounded-lg ${isSelected ? 'bg-blue-100/80' : 'bg-slate-100 group-hover:bg-slate-200/70'}`}>
                    {getRoomIcon(room.icon, isSelected)}
                  </span>
                  <div className="min-w-0">
                    <div className="text-xs truncate font-medium flex items-center gap-1.5">
                      {room.name}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[130px]">
                      {room.description}
                    </div>
                  </div>
                </div>

                {/* Online indicator */}
                <div className="flex items-center gap-1 flex-shrink-0">
                  {count > 0 && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-100">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      {count}
                    </span>
                  )}
                </div>
              </button>
            );
          })}

          {filteredRooms.length === 0 && (
            <div className="p-4 text-center text-xs text-slate-400">
              Không tìm thấy phòng phù hợp.
            </div>
          )}
        </div>

        {/* Live Tips Banner */}
        <div className="p-3 mx-3 mb-2 bg-gradient-to-br from-indigo-50/80 to-blue-50/80 border border-indigo-100 rounded-xl">
          <div className="flex items-start gap-2">
            <Radio className="w-4 h-4 text-indigo-600 flex-shrink-0 mt-0.5 animate-pulse" />
            <div className="text-[11px] text-indigo-900">
              <span className="font-semibold">Mẹo mời bạn bè:</span> Bạn chỉ cần bấm nút <b>"Mời vào phòng"</b> ở góc trên để gửi link cho người khác cùng trao đổi.
            </div>
          </div>
        </div>

        {/* User Identity Footer */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/60">
          <div className="flex items-center justify-between">
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 text-left min-w-0 group hover:opacity-90 transition flex-1 mr-2"
              title="Nhấn để đổi tên hoặc avatar"
            >
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-2xs border border-white flex-shrink-0"
                style={{ backgroundColor: currentUser.color || '#3B82F6' }}
              >
                {currentUser.avatar || '👤'}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-semibold text-slate-800 truncate group-hover:text-blue-600">
                  {currentUser.name}
                </div>
                <div className="text-[10px] text-slate-500 truncate">
                  {currentUser.statusMessage || 'Đang trực tuyến'}
                </div>
              </div>
            </button>

            <button
              id="btn-sidebar-settings"
              onClick={onOpenProfile}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition"
              title="Tuỳ chỉnh hồ sơ"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
