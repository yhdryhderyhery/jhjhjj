import React, { useState } from 'react';
import { X, Eye, EyeOff, Shield, Sparkles, Moon, Sun, Crosshair, Users, Flame } from 'lucide-react';
import type { WerewolfRole, WerewolfFaction } from '../../werewolfTypes';
import { playRoleRevealChime } from '../../utils/audio';

interface RoleCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  role?: WerewolfRole;
  faction?: WerewolfFaction;
  isAlive?: boolean;
}

interface RoleMetadata {
  name: string;
  factionName: string;
  factionColor: string;
  icon: string;
  description: string;
  nightAction: string;
  tip: string;
  bgGradient: string;
}

const ROLE_INFO: Record<WerewolfRole, RoleMetadata> = {
  werewolf: {
    name: 'Ma Sói',
    factionName: 'Phe Ma Sói',
    factionColor: 'bg-red-500/10 text-red-500 border-red-500/30',
    icon: '🐺',
    description: 'Sinh vật săn mồi khát máu đội lốt con người trong làng.',
    nightAction: 'Mỗi đêm thức giấc cùng đồng đội để chọn 1 nạn nhân cắn chết. Có thể trò chuyện kín tại kênh "Hang Sói".',
    tip: 'Hãy giả vờ làm dân làng ngoan ngoãn vào ban ngày, dẫn dắt các cuộc tranh luận để nghi ngờ người vô tội mà không để lộ chân tướng!',
    bgGradient: 'from-red-950 via-slate-900 to-black',
  },
  seer: {
    name: 'Tiên Tri',
    factionName: 'Phe Dân Làng',
    factionColor: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    icon: '🔮',
    description: 'Người sở hữu đôi mắt thần thấu suốt mọi điều tà ác trong bóng tối.',
    nightAction: 'Mỗi đêm được chọn 1 người chơi bất kỳ để soi danh tính và biết chính xác người đó là Ma Sói hay Dân.',
    tip: 'Giữ bí mật thân phận ở giai đoạn đầu để tránh bị Sói cắn sớm. Khi đã soi ra Sói, hãy khéo léo định hướng làng treo cổ hắn!',
    bgGradient: 'from-purple-950 via-slate-900 to-black',
  },
  bodyguard: {
    name: 'Bảo Vệ',
    factionName: 'Phe Dân Làng',
    factionColor: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    icon: '🛡️',
    description: 'Hiệp sĩ dũng cảm sẵn sàng xả thân che chở dân làng khỏi nanh vuốt sói.',
    nightAction: 'Mỗi đêm chọn 1 người để bảo vệ khỏi bị Sói cắn (có thể bảo vệ chính mình, nhưng không thể bảo vệ cùng 1 người 2 đêm liên tiếp).',
    tip: 'Hãy phán đoán ai có nguy cơ bị Sói tấn công cao nhất đêm nay (như người nghi là Tiên Tri hoặc người có tiếng nói quan trọng).',
    bgGradient: 'from-blue-950 via-slate-900 to-black',
  },
  witch: {
    name: 'Phù Thủy',
    factionName: 'Phe Dân Làng',
    factionColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    icon: '🧙‍♀️',
    description: 'Bậc thầy luyện đan sở hữu 2 bình thuốc thần kỳ: Cứu mạng và Thuốc độc.',
    nightAction: 'Được biết ai bị Sói cắn trong đêm. Có 1 bình Cứu để cứu sống nạn nhân và 1 bình Độc để giết 1 người tùy ý.',
    tip: 'Mỗi bình thuốc chỉ dùng được 1 lần trong cả ván đấu. Hãy cân nhắc thật kỹ thời điểm sử dụng để xoay chuyển cục diện!',
    bgGradient: 'from-emerald-950 via-slate-900 to-black',
  },
  hunter: {
    name: 'Thợ Săn',
    factionName: 'Phe Dân Làng',
    factionColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    icon: '🏹',
    description: 'Xạ thủ cừ khôi không bao giờ chịu gục ngã trong im lặng.',
    nightAction: 'Không hành động vào ban đêm. Tuy nhiên, khi bạn bị Sói cắn hoặc bị làng treo cổ, bạn có quyền bắn 1 phát đạn kéo theo 1 người khác cùng chết!',
    tip: 'Nếu bị đưa lên giàn treo cổ hoặc trúng độc, hãy dùng phát bắn cuối cùng để hạ gục kẻ bạn nghi ngờ là Ma Sói nguy hiểm nhất.',
    bgGradient: 'from-amber-950 via-slate-900 to-black',
  },
  villager: {
    name: 'Dân Làng',
    factionName: 'Phe Dân Làng',
    factionColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    icon: '👨‍🌾',
    description: 'Người dân chất phác nhưng mang trong mình sức mạnh của sự đoàn kết và trí tuệ suy luận.',
    nightAction: 'Ngủ say vào ban đêm để dưỡng sức.',
    tip: 'Vũ khí mạnh nhất của bạn là khả năng quan sát lời khai, so sánh các phiếu bầu và phân tích hành vi để lật tẩy kẻ dối trá.',
    bgGradient: 'from-slate-900 via-slate-950 to-black',
  },
};

export function RoleCardModal({
  isOpen,
  onClose,
  role,
  faction,
  isAlive = true,
}: RoleCardModalProps) {
  const [isRevealed, setIsRevealed] = useState(false);

  if (!isOpen) return null;

  const currentRole = role || 'villager';
  const meta = ROLE_INFO[currentRole];

  const handleToggleReveal = () => {
    if (!isRevealed) {
      playRoleRevealChime();
    }
    setIsRevealed(!isRevealed);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md p-6 text-white shadow-2xl relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 rounded-full bg-red-600/20 blur-3xl pointer-events-none" />
        <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-purple-600/20 blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 border border-slate-700 text-slate-300 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Thẻ Bài Định Mệnh Của Bạn
          </div>
          <h3 className="text-xl font-bold text-slate-100">Bí Mật Vai Trò</h3>
          <p className="text-xs text-slate-400">
            Chỉ có bạn mới nhìn thấy vai trò này. Hãy cẩn thận khi xem ở nơi đông người!
          </p>
        </div>

        {/* The Card View with Flip/Reveal mechanic */}
        <div className="relative my-4 perspective-1000">
          <div
            onClick={handleToggleReveal}
            className={`cursor-pointer w-full rounded-2xl p-6 transition-all duration-500 border relative overflow-hidden flex flex-col items-center justify-center text-center select-none shadow-xl ${
              isRevealed
                ? `bg-linear-to-b ${meta.bgGradient} border-slate-600`
                : 'bg-linear-to-b from-slate-800 to-slate-950 border-slate-700 hover:border-slate-500'
            }`}
            style={{ minHeight: '260px' }}
          >
            {isRevealed ? (
              <div className="w-full animate-in zoom-in-95 duration-200">
                <div className="text-6xl mb-3 drop-shadow-md">{meta.icon}</div>
                <div className="text-2xl font-black text-white tracking-wide mb-1">
                  {meta.name}
                </div>
                <div className="inline-block mb-3">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold border ${meta.factionColor}`}
                  >
                    {meta.factionName}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed max-w-xs mx-auto mb-3">
                  {meta.description}
                </p>
                <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>Bấm để che lại</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-slate-800/80 border border-slate-600 flex items-center justify-center text-3xl shadow-inner">
                  ❓
                </div>
                <div className="text-sm font-bold text-slate-200">
                  Thẻ Đang Được Che Giấu
                </div>
                <div className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md">
                  <Eye className="w-4 h-4" />
                  <span>Bấm để lật xem vai trò</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Detailed instructions */}
        {isRevealed && (
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5 space-y-2 text-xs text-slate-300 mb-4 animate-in fade-in duration-200">
            <div>
              <span className="font-semibold text-amber-400 flex items-center gap-1 mb-0.5">
                <Moon className="w-3.5 h-3.5" /> Nhiệm vụ ban đêm:
              </span>
              <p className="text-slate-300 pl-4">{meta.nightAction}</p>
            </div>
            <div>
              <span className="font-semibold text-emerald-400 flex items-center gap-1 mb-0.5">
                <Sparkles className="w-3.5 h-3.5" /> Chiến thuật khuyên dùng:
              </span>
              <p className="text-slate-300 pl-4">{meta.tip}</p>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <div className="text-xs text-slate-400">
            Trạng thái:{' '}
            <span className={isAlive ? 'text-emerald-400 font-semibold' : 'text-red-400 font-semibold'}>
              {isAlive ? '🟢 Còn sống' : '💀 Đã chết'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
          >
            Đã hiểu
          </button>
        </div>
      </div>
    </div>
  );
}
