import React, { useState, useEffect } from 'react';
import {
  X,
  FileText,
  Search,
  CheckCircle2,
  AlertTriangle,
  Skull,
  Shield,
  HelpCircle,
  Eye,
  Scroll,
  Calendar,
  Save,
  Clock,
  Sparkles,
} from 'lucide-react';
import type { WerewolfPlayer, WerewolfLogEntry, DeductionNote, WerewolfRole } from '../../werewolfTypes';

interface InvestigationDossierModalProps {
  isOpen: boolean;
  onClose: () => void;
  players: WerewolfPlayer[];
  logs: WerewolfLogEntry[];
  seerHistory?: Array<{
    targetId: string;
    targetName: string;
    isWolf: boolean;
    round: number;
  }>;
  roomId: string;
}

const ROLE_OPTIONS: Array<{ value: WerewolfRole | 'unknown'; label: string; icon: string }> = [
  { value: 'unknown', label: 'Chưa rõ vai', icon: '❓' },
  { value: 'villager', label: 'Dân Làng', icon: '👨‍🌾' },
  { value: 'werewolf', label: 'Ma Sói', icon: '🐺' },
  { value: 'seer', label: 'Tiên Tri', icon: '🔮' },
  { value: 'bodyguard', label: 'Bảo Vệ', icon: '🛡️' },
  { value: 'witch', label: 'Phù Thủy', icon: '🧙‍♀️' },
  { value: 'hunter', label: 'Thợ Săn', icon: '🏹' },
];

export function InvestigationDossierModal({
  isOpen,
  onClose,
  players,
  logs,
  seerHistory = [],
  roomId,
}: InvestigationDossierModalProps) {
  const [activeTab, setActiveTab] = useState<'suspects' | 'timeline' | 'seer'>('suspects');
  const [notesByPlayer, setNotesByPlayer] = useState<Record<string, DeductionNote>>(() => {
    if (typeof window !== 'undefined') {
      const cached = localStorage.getItem(`ww_notes_${roomId}`);
      if (cached) {
        try {
          return JSON.parse(cached);
        } catch {
          // fallback
        }
      }
    }
    return {};
  });

  const [savedToast, setSavedToast] = useState(false);

  // Sync to localStorage
  const handleUpdateNote = (
    playerId: string,
    field: keyof DeductionNote,
    value: unknown
  ) => {
    setNotesByPlayer((prev) => {
      const current = prev[playerId] || {
        targetId: playerId,
        status: 'unknown',
        claimedRole: 'unknown',
        notes: '',
        updatedAt: Date.now(),
      };
      const updated = {
        ...prev,
        [playerId]: {
          ...current,
          [field]: value,
          updatedAt: Date.now(),
        },
      };
      if (typeof window !== 'undefined') {
        localStorage.setItem(`ww_notes_${roomId}`, JSON.stringify(updated));
      }
      return updated;
    });

    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 1500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col text-white shadow-2xl overflow-hidden relative">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <Scroll className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-100">
                  Hồ Sơ Điều Tra & Sổ Tay Suy Luận
                </h3>
                {savedToast && (
                  <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1 animate-in fade-in">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Đã lưu
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Ghi chú lời khai, đánh dấu kẻ tình nghi và phân tích mâu thuẫn để tìm ra Ma Sói
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-5 pt-3 border-b border-slate-800 bg-slate-950/40 text-xs">
          <button
            onClick={() => setActiveTab('suspects')}
            className={`px-4 py-2.5 font-semibold rounded-t-xl transition flex items-center gap-1.5 border-b-2 ${
              activeTab === 'suspects'
                ? 'border-blue-500 text-blue-400 bg-slate-800/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>Bảng Phân Tích Nghi Can ({players.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-4 py-2.5 font-semibold rounded-t-xl transition flex items-center gap-1.5 border-b-2 ${
              activeTab === 'timeline'
                ? 'border-blue-500 text-blue-400 bg-slate-800/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Biên Bản Diễn Biến ({logs.length})</span>
          </button>

          {seerHistory.length > 0 && (
            <button
              onClick={() => setActiveTab('seer')}
              className={`px-4 py-2.5 font-semibold rounded-t-xl transition flex items-center gap-1.5 border-b-2 ${
                activeTab === 'seer'
                  ? 'border-purple-500 text-purple-400 bg-slate-800/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Eye className="w-4 h-4" />
              <span>Nhật Ký Tiên Tri ({seerHistory.length})</span>
            </button>
          )}
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeTab === 'suspects' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {players.map((player) => {
                  const note = notesByPlayer[player.id] || {
                    targetId: player.id,
                    status: 'unknown',
                    claimedRole: 'unknown',
                    notes: '',
                    updatedAt: Date.now(),
                  };

                  return (
                    <div
                      key={player.id}
                      className={`p-4 rounded-2xl border transition-all ${
                        !player.isAlive
                          ? 'bg-slate-950/60 border-slate-800/80 opacity-70'
                          : note.status === 'confirmed_wolf'
                          ? 'bg-red-950/20 border-red-500/40'
                          : note.status === 'suspect'
                          ? 'bg-amber-950/20 border-amber-500/40'
                          : note.status === 'innocent'
                          ? 'bg-emerald-950/20 border-emerald-500/40'
                          : 'bg-slate-800/40 border-slate-700/60'
                      }`}
                    >
                      {/* Player Row */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                            style={{ backgroundColor: `${player.color}25` }}
                          >
                            {player.avatar}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 font-bold text-sm text-slate-100 truncate">
                              <span>{player.name}</span>
                              {player.isBot && (
                                <span className="text-[10px] px-1.5 py-0.2 bg-slate-700 text-slate-300 rounded font-normal">
                                  Bot
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {player.isAlive ? (
                                <span className="text-emerald-400 font-medium">● Còn sống</span>
                              ) : (
                                <span className="text-red-400 font-medium">
                                  💀 Đã chết ({player.deathReason === 'werewolf' ? 'Sói cắn' : player.deathReason === 'lynch' ? 'Treo cổ' : 'Thuốc độc'})
                                </span>
                              )}
                              {player.revealedRole && (
                                <span className="ml-1.5 text-amber-300 font-semibold">
                                  [{player.revealedRole.toUpperCase()}]
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Status Tag Selector */}
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button
                            title="Đánh dấu vô tội"
                            onClick={() => handleUpdateNote(player.id, 'status', note.status === 'innocent' ? 'unknown' : 'innocent')}
                            className={`p-1.5 rounded-lg border text-xs transition ${
                              note.status === 'innocent'
                                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            <CheckCircle2 className="w-4 h-4" />
                          </button>

                          <button
                            title="Khả nghi"
                            onClick={() => handleUpdateNote(player.id, 'status', note.status === 'suspect' ? 'unknown' : 'suspect')}
                            className={`p-1.5 rounded-lg border text-xs transition ${
                              note.status === 'suspect'
                                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            <AlertTriangle className="w-4 h-4" />
                          </button>

                          <button
                            title="Chắc chắn là Sói"
                            onClick={() => handleUpdateNote(player.id, 'status', note.status === 'confirmed_wolf' ? 'unknown' : 'confirmed_wolf')}
                            className={`p-1.5 rounded-lg border text-xs transition ${
                              note.status === 'confirmed_wolf'
                                ? 'bg-red-500/20 border-red-500 text-red-300'
                                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            <span className="text-sm leading-none">🐺</span>
                          </button>
                        </div>
                      </div>

                      {/* Claimed / Suspected Role */}
                      <div className="mb-2.5">
                        <label className="block text-[11px] text-slate-400 mb-1">
                          Vai trò nghi vấn / Tự nhận:
                        </label>
                        <select
                          value={note.claimedRole || 'unknown'}
                          onChange={(e) => handleUpdateNote(player.id, 'claimedRole', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
                        >
                          {ROLE_OPTIONS.map((opt) => (
                            <option key={opt.value} value={opt.value}>
                              {opt.icon} {opt.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Freeform Deduction Notes */}
                      <div>
                        <input
                          type="text"
                          placeholder="Ghi chú suy luận: ngày 1 vote ai, mâu thuẫn lời khai..."
                          value={note.notes || ''}
                          onChange={(e) => handleUpdateNote(player.id, 'notes', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'timeline' && (
            <div className="space-y-2.5">
              {logs.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  Chưa có sự kiện nào được ghi nhận. Ván đấu đang ở sảnh chờ.
                </div>
              ) : (
                logs.map((log) => (
                  <div
                    key={log.id}
                    className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 leading-relaxed ${
                      log.type === 'kill'
                        ? 'bg-red-950/20 border-red-500/30 text-red-200'
                        : log.type === 'lynch'
                        ? 'bg-amber-950/20 border-amber-500/30 text-amber-200'
                        : log.type === 'hunter'
                        ? 'bg-purple-950/20 border-purple-500/30 text-purple-200'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-300'
                    }`}
                  >
                    <div className="mt-0.5 text-base flex-shrink-0">
                      {log.type === 'kill'
                        ? '🩸'
                        : log.type === 'lynch'
                        ? '⚖️'
                        : log.type === 'hunter'
                        ? '🏹'
                        : '📜'}
                    </div>
                    <div className="flex-1">
                      <div className="text-[10px] text-slate-400 font-mono mb-0.5">
                        {log.round > 0 ? `Vòng ${log.round}` : 'Chuẩn bị'} • {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </div>
                      <div>{log.content}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'seer' && (
            <div className="space-y-3">
              <div className="bg-purple-950/20 border border-purple-500/30 rounded-2xl p-4 text-xs text-purple-200">
                <div className="font-bold flex items-center gap-1.5 mb-1 text-sm text-purple-300">
                  <Eye className="w-4 h-4" /> Kết Quả Soi Của Tiên Tri
                </div>
                <p className="text-slate-300 text-[11px]">
                  Danh sách những người chơi bạn đã soi sáng trong các đêm vừa qua. Hãy vận dụng thông tin này để bảo vệ làng!
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {seerHistory.map((item, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl border flex items-center justify-between ${
                      item.isWolf
                        ? 'bg-red-950/30 border-red-500/50'
                        : 'bg-emerald-950/30 border-emerald-500/50'
                    }`}
                  >
                    <div>
                      <div className="text-[11px] text-slate-400 mb-0.5">
                        Đêm thứ {item.round}
                      </div>
                      <div className="font-bold text-sm text-white">{item.targetName}</div>
                    </div>
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${
                        item.isWolf
                          ? 'bg-red-500/20 border-red-500 text-red-300'
                          : 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      }`}
                    >
                      {item.isWolf ? '🐺 LÀ MA SÓI!' : '✅ VÔ TỘI / DÂN'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Save className="w-3.5 h-3.5 text-blue-400" />
            <span>Sổ tay tự động lưu vào trình duyệt của bạn</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
          >
            Đóng sổ tay
          </button>
        </div>
      </div>
    </div>
  );
}
