import React from 'react';
import { X, BookOpen, Moon, Sun, Shield, Users, CheckCircle2, Award } from 'lucide-react';

interface WerewolfRulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WerewolfRulesModal({ isOpen, onClose }: WerewolfRulesModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col text-white shadow-2xl overflow-hidden relative">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                Luật Chơi & Cẩm Nang Ma Sói (Werewolf)
              </h3>
              <p className="text-xs text-slate-400">
                Trò chơi đấu trí ẩn danh kinh điển giữa Dân Làng và Ma Sói
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-300 leading-relaxed">
          {/* Mục tiêu & Điều kiện thắng */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-2xl p-4 space-y-2">
            <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" /> Mục Tiêu Chiến Thắng
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                <span className="font-bold text-emerald-400 block mb-1">
                  🏰 Phe Dân Làng
                </span>
                <span>
                  Tìm ra và treo cổ toàn bộ Ma Sói trong làng qua các cuộc thảo luận và bỏ phiếu ban ngày.
                </span>
              </div>
              <div className="p-3 rounded-xl bg-red-950/20 border border-red-500/30">
                <span className="font-bold text-red-400 block mb-1">
                  🐺 Phe Ma Sói
                </span>
                <span>
                  Ẩn mình, chia rẽ dân làng và săn mồi vào ban đêm cho đến khi số lượng Sói bằng hoặc lớn hơn số Dân còn sống.
                </span>
              </div>
            </div>
          </div>

          {/* Vòng tuần hoàn ngày và đêm */}
          <div className="space-y-3">
            <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Moon className="w-4 h-4 text-purple-400" /> Chu Trình Ván Đấu (Ngày & Đêm)
            </div>

            <div className="space-y-2">
              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/50">
                <div className="font-semibold text-slate-200 flex items-center gap-1.5 mb-1">
                  <Moon className="w-3.5 h-3.5 text-blue-400" /> 1. Giai Đoạn Ban Đêm (Night Phase)
                </div>
                <p className="text-slate-400">
                  Cả làng đi ngủ. Các nhân vật có chức năng lần lượt thức giấc theo thứ tự:
                </p>
                <ul className="list-disc list-inside mt-1.5 space-y-1 text-slate-300">
                  <li><strong>Bảo Vệ:</strong> Chọn 1 người để bảo hộ khỏi nanh vuốt Sói.</li>
                  <li><strong>Ma Sói:</strong> Thức giấc cùng nhau, bàn bạc tại kênh Hang Sói và chọn 1 con mồi.</li>
                  <li><strong>Tiên Tri:</strong> Chọn 1 người để soi xem người đó là Sói hay Dân.</li>
                  <li><strong>Phù Thủy:</strong> Biết ai bị Sói cắn; quyết định có dùng bình Cứu hoặc bình Độc hay không.</li>
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/50">
                <div className="font-semibold text-slate-200 flex items-center gap-1.5 mb-1">
                  <Sun className="w-3.5 h-3.5 text-amber-400" /> 2. Bình Minh & Thảo Luận (Day Discussion)
                </div>
                <p className="text-slate-400">
                  Quản trò thông báo tình hình người chết đêm qua (hoặc một đêm bình yên không ai chết). Mọi người cùng bật mic, nhắn tin trao đổi, đối chiếu lời khai và bảo vệ sự trong sạch của bản thân.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/50">
                <div className="font-semibold text-slate-200 flex items-center gap-1.5 mb-1">
                  <span className="text-base leading-none">⚖️</span> 3. Bỏ Phiếu Treo Cổ (Voting)
                </div>
                <p className="text-slate-400">
                  Dân làng biểu quyết chọn ra người khả nghi nhất để đưa lên giàn treo cổ. Người nhận nhiều phiếu nhất sẽ bị loại khỏi cuộc chơi và lật thẻ vai trò. Nếu phiếu bằng nhau, làng không treo cổ ai.
                </p>
              </div>
            </div>
          </div>

          {/* Các chức năng đặc biệt */}
          <div className="space-y-3">
            <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" /> Chi Tiết Các Vai Trò
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40">
                <span className="font-bold text-red-400">🐺 Ma Sói</span>
                <p className="text-slate-400 mt-1">
                  Biết mặt nhau từ đầu, cắn chết 1 người mỗi đêm, có thể chat mật tại kênh riêng.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40">
                <span className="font-bold text-purple-400">🔮 Tiên Tri</span>
                <p className="text-slate-400 mt-1">
                  Mỗi đêm soi 1 người để biết có phải là Sói hay không.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40">
                <span className="font-bold text-blue-400">🛡️ Bảo Vệ</span>
                <p className="text-slate-400 mt-1">
                  Bảo vệ 1 người mỗi đêm. Không thể bảo vệ cùng 1 người 2 đêm liền.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40">
                <span className="font-bold text-emerald-400">🧙‍♀️ Phù Thủy</span>
                <p className="text-slate-400 mt-1">
                  Có 1 bình thuốc Cứu sống và 1 bình thuốc Độc, mỗi bình chỉ dùng 1 lần cả ván.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40">
                <span className="font-bold text-amber-400">🏹 Thợ Săn</span>
                <p className="text-slate-400 mt-1">
                  Khi chết được quyền bắn chết thêm 1 người bất kỳ trước khi ngã xuống.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40">
                <span className="font-bold text-slate-300">👨‍🌾 Dân Làng</span>
                <p className="text-slate-400 mt-1">
                  Không có kỹ năng ban đêm nhưng là tiếng nói công lý quyết định các lá phiếu ban ngày.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition shadow-md"
          >
            Đã Rõ Luật Chơi
          </button>
        </div>
      </div>
    </div>
  );
}
