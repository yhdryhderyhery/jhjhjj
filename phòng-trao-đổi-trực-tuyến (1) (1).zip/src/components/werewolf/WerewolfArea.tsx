import React, { useState, useEffect, useRef } from 'react';
import {
  Moon,
  Sun,
  Shield,
  Eye,
  Sparkles,
  Users,
  Play,
  RotateCcw,
  UserPlus,
  Send,
  Skull,
  Award,
  BookOpen,
  Scroll,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ChevronRight,
  Flame,
  Volume2,
} from 'lucide-react';
import type {
  UserProfile,
  Room,
  WerewolfClientSyncPayload,
  WerewolfChatMessage,
  WerewolfActionType,
  WerewolfRole,
  WerewolfPhase,
} from '../../types';
import { RoleCardModal } from './RoleCardModal';
import { InvestigationDossierModal } from './InvestigationDossierModal';
import { WerewolfRulesModal } from './WerewolfRulesModal';
import {
  playWolfHowl,
  playMorningBell,
  playGavel,
  playMessageChime,
} from '../../utils/audio';

interface WerewolfAreaProps {
  user: UserProfile;
  room: Room;
  gameState: WerewolfClientSyncPayload | null;
  chatMessages: WerewolfChatMessage[];
  onJoinSeat: () => void;
  onLeaveSeat: () => void;
  onAddBots: (count: number) => void;
  onStartGame: () => void;
  onResetGame: () => void;
  onAction: (action: WerewolfActionType, targetId?: string) => void;
  onSendChat: (content: string, channel: 'village' | 'wolf' | 'ghost') => void;
  onNextPhase: () => void;
}

export function WerewolfArea({
  user,
  room,
  gameState,
  chatMessages,
  onJoinSeat,
  onLeaveSeat,
  onAddBots,
  onStartGame,
  onResetGame,
  onAction,
  onSendChat,
  onNextPhase,
}: WerewolfAreaProps) {
  // Modals state
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showDossierModal, setShowDossierModal] = useState(false);
  const [showRulesModal, setShowRulesModal] = useState(false);

  // Chat tab state
  const [chatChannel, setChatChannel] = useState<'village' | 'wolf' | 'ghost'>('village');
  const [chatInput, setChatInput] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Sound triggering on phase change
  const prevPhaseRef = useRef<WerewolfPhase | undefined>(undefined);
  useEffect(() => {
    if (!gameState) return;
    const prev = prevPhaseRef.current;
    const current = gameState.phase;

    if (prev !== current) {
      if (current === 'night') {
        playWolfHowl();
      } else if (current === 'day_discuss') {
        playMorningBell();
      } else if (current === 'day_vote') {
        playGavel();
      }
      prevPhaseRef.current = current;
    }
  }, [gameState?.phase]);

  // Auto scroll chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages.length, chatChannel]);

  if (!gameState) {
    return (
      <div className="flex-1 flex items-center justify-center p-8 text-center text-slate-400">
        <div className="space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-2xl animate-pulse">
            🐺
          </div>
          <p className="text-sm font-medium">Đang kết nối vào làng Ma Sói...</p>
        </div>
      </div>
    );
  }

  const {
    phase,
    nightSubPhase,
    round,
    players,
    timerSeconds,
    timerTotal,
    narratorMessage,
    myRole,
    myFaction,
    isSeated,
    winner,
    seerHistory,
    logs,
    wolfVotes,
    dayVotes,
    nightPending,
    witchPotions,
    isHost,
  } = gameState;

  const myPlayer = players.find((p) => p.id === user.id);
  const isAlive = myPlayer ? myPlayer.isAlive : false;
  const isWolf = myRole === 'werewolf';

  // Filter messages for current channel
  const filteredMessages = chatMessages.filter((m) => {
    if (chatChannel === 'village') return m.channel === 'village' || m.channel === 'narrator';
    if (chatChannel === 'wolf') return m.channel === 'wolf';
    if (chatChannel === 'ghost') return m.channel === 'ghost';
    return true;
  });

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    onSendChat(chatInput.trim(), chatChannel);
    setChatInput('');
  };

  // Phase Display Meta
  const getPhaseMeta = () => {
    switch (phase) {
      case 'lobby':
        return {
          title: 'Sảnh Chờ Ghép Bàn',
          desc: 'Tập hợp dân làng (ít nhất 4-6 người) để chuẩn bị bước vào cuộc chiến sinh tồn.',
          theme: 'from-slate-900 to-slate-950',
          badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
          icon: '🏰',
        };
      case 'night':
        return {
          title: `Đêm Thứ ${round}: Màn Đêm Buông Xuống`,
          desc:
            nightSubPhase === 'werewolf'
              ? '🐺 Ma Sói đang thức giấc tìm kiếm con mồi...'
              : nightSubPhase === 'seer'
              ? '🔮 Tiên Tri đang mở con mắt thần để soi chân tướng...'
              : nightSubPhase === 'bodyguard'
              ? '🛡️ Bảo Vệ đang âm thầm chọn người để che chở...'
              : nightSubPhase === 'witch'
              ? '🧙‍♀️ Phù Thủy đang cân nhắc bình dược sinh tử...'
              : 'Màn đêm tĩnh mịch bao trùm cả làng...',
          theme: 'from-slate-950 via-indigo-950/60 to-black',
          badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
          icon: '🌙',
        };
      case 'day_discuss':
        return {
          title: `Ngày Thứ ${round}: Bình Minh & Thảo Luận`,
          desc: 'Quản trò điểm danh người sống sót. Cả làng cùng tranh luận tìm ra Ma Sói!',
          theme: 'from-amber-950/30 via-slate-900 to-slate-950',
          badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
          icon: '☀️',
        };
      case 'day_vote':
        return {
          title: `Ngày Thứ ${round}: Biểu Quyết Treo Cổ`,
          desc: 'Bỏ phiếu chọn người khả nghi nhất để đưa lên giàn thiêu!',
          theme: 'from-red-950/30 via-slate-900 to-slate-950',
          badgeColor: 'bg-red-500/10 text-red-400 border-red-500/30',
          icon: '⚖️',
        };
      case 'hunter_revenge':
        return {
          title: 'Phát Bắn Báo Thù Của Thợ Săn',
          desc: 'Thợ Săn trước khi trút hơi thở cuối cùng được quyền kéo 1 kẻ khác cùng chết!',
          theme: 'from-amber-950/40 via-slate-900 to-black',
          badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
          icon: '🏹',
        };
      case 'game_over':
        return {
          title: 'Kết Thúc Ván Đấu',
          desc: winner === 'werewolf' ? '🐺 PHE MA SÓI ĐÃ CHIẾN THẮNG!' : '🏰 PHE DÂN LÀNG ĐÃ CHIẾN THẮNG!',
          theme: winner === 'werewolf' ? 'from-red-950/40 to-slate-950' : 'from-emerald-950/40 to-slate-950',
          badgeColor: winner === 'werewolf' ? 'bg-red-500/10 text-red-400 border-red-500/30' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
          icon: '🏆',
        };
    }
  };

  const meta = getPhaseMeta();
  const timerPercentage = timerTotal > 0 ? Math.max(0, Math.min(100, (timerSeconds / timerTotal) * 100)) : 0;

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-slate-950 text-slate-100 relative overflow-hidden select-none">
      {/* Background Ambience Gradient */}
      <div className={`absolute inset-0 bg-gradient-to-b ${meta.theme} opacity-80 pointer-events-none transition-colors duration-1000`} />

      {/* Top Header Bar */}
      <div className="relative z-10 px-4 py-3 border-b border-slate-800/80 bg-slate-900/80 backdrop-blur-md flex flex-wrap items-center justify-between gap-3">
        {/* Left: Phase Title & Timer */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-slate-800 border border-slate-700/80 flex items-center justify-center text-xl shadow-md">
            {meta.icon}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${meta.badgeColor}`}>
                {meta.title}
              </span>
              {timerSeconds > 0 && (
                <span className="flex items-center gap-1 text-xs font-mono font-bold text-amber-400">
                  <Clock className="w-3.5 h-3.5" />
                  {timerSeconds}s
                </span>
              )}
            </div>
            <p className="text-xs text-slate-300 mt-0.5 max-w-md truncate">
              {meta.desc}
            </p>
          </div>
        </div>

        {/* Right: Quick Action Controls */}
        <div className="flex items-center gap-2">
          {/* Secret Role Card Button */}
          {myRole && (
            <button
              onClick={() => setShowRoleModal(true)}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Xem Thẻ Bài ({myRole.toUpperCase()})</span>
            </button>
          )}

          {/* Dossier Notebook */}
          <button
            onClick={() => setShowDossierModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
          >
            <Scroll className="w-3.5 h-3.5 text-amber-400" />
            <span>Sổ Tay Thám Tử</span>
          </button>

          {/* Rules Modal */}
          <button
            onClick={() => setShowRulesModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Luật</span>
          </button>

          {/* Host Controls */}
          {phase !== 'lobby' && (
            <button
              onClick={onNextPhase}
              title="Bỏ qua chờ đợi để sang pha tiếp theo ngay"
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1 transition"
            >
              <ChevronRight className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Pha kế</span>
            </button>
          )}

          {phase !== 'lobby' && (
            <button
              onClick={onResetGame}
              title="Đặt lại ván cờ về sảnh chờ"
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-red-400 transition"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Timer Progress Bar */}
      {timerTotal > 0 && phase !== 'lobby' && (
        <div className="w-full h-1 bg-slate-800 relative overflow-hidden">
          <div
            className="h-full bg-linear-to-r from-blue-500 via-purple-500 to-amber-500 transition-all duration-1000 ease-linear"
            style={{ width: `${timerPercentage}%` }}
          />
        </div>
      )}

      {/* Narrator Banner */}
      {narratorMessage && (
        <div className="relative z-10 px-4 py-2 bg-slate-900/90 border-b border-slate-800 text-xs text-amber-300 flex items-center justify-center gap-2 font-medium animate-in fade-in">
          <span className="text-base">📢</span>
          <span>{narratorMessage}</span>
        </div>
      )}

      {/* Main Game Arena (Split into Village Table and Werewolf Log/Chat) */}
      <div className="relative z-10 flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left Side: Village Table & Action Controls */}
        <div className="flex-1 flex flex-col min-h-0 overflow-y-auto p-4 space-y-4">
          {/* Lobby View */}
          {phase === 'lobby' && (
            <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-xl mx-auto w-full text-center space-y-6">
              <div className="space-y-2">
                <div className="w-16 h-16 rounded-3xl bg-linear-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-3xl mx-auto shadow-xl shadow-purple-900/30">
                  🌕
                </div>
                <h2 className="text-xl font-black text-white">
                  Bàn Tròn Làng Ma Sói
                </h2>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Hiện có {players.length} người đang ngồi tại bàn. Cần tối thiểu 4 người chơi để bắt đầu phân vai!
                </p>
              </div>

              {/* Seating Table Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full">
                {players.map((p, idx) => (
                  <div
                    key={p.id}
                    className={`p-3 rounded-2xl border flex flex-col items-center justify-center relative transition-all ${
                      p.id === user.id
                        ? 'bg-blue-950/40 border-blue-500/60 ring-2 ring-blue-500/20'
                        : 'bg-slate-900/70 border-slate-800'
                    }`}
                  >
                    <div
                      className="w-11 h-11 rounded-2xl flex items-center justify-center text-xl mb-1.5 shadow-md"
                      style={{ backgroundColor: `${p.color}30` }}
                    >
                      {p.avatar}
                    </div>
                    <div className="text-xs font-bold text-slate-200 truncate w-full text-center">
                      {p.name}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {p.id === user.id ? 'Bạn' : p.isBot ? 'Bot' : 'Người chơi'}
                    </div>
                    <div className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-slate-800 border border-slate-700 text-[10px] font-bold text-slate-400 flex items-center justify-center">
                      {idx + 1}
                    </div>
                  </div>
                ))}

                {/* Empty Placeholders */}
                {Array.from({ length: Math.max(0, 8 - players.length) }).map((_, i) => (
                  <div
                    key={`empty-${i}`}
                    className="p-3 rounded-2xl border border-dashed border-slate-800 flex flex-col items-center justify-center text-slate-600 min-h-[96px]"
                  >
                    <Users className="w-5 h-5 mb-1 opacity-40" />
                    <span className="text-[11px]">Ghế trống</span>
                  </div>
                ))}
              </div>

              {/* Lobby Action Controls */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                {!isSeated ? (
                  <button
                    onClick={onJoinSeat}
                    className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-900/30 transition flex items-center gap-2"
                  >
                    <Users className="w-4 h-4" />
                    <span>Ngồi Vào Bàn Chơi</span>
                  </button>
                ) : (
                  <button
                    onClick={onLeaveSeat}
                    className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs border border-slate-700 transition"
                  >
                    Rời Khỏi Bàn
                  </button>
                )}

                <button
                  onClick={() => onAddBots(6)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-xs border border-slate-700 transition flex items-center gap-1.5"
                >
                  <UserPlus className="w-4 h-4 text-amber-400" />
                  <span>Thêm 6 Bot Đủ Bàn</span>
                </button>

                <button
                  onClick={onStartGame}
                  disabled={players.length < 4}
                  className={`px-6 py-2.5 rounded-xl font-bold text-xs shadow-lg transition flex items-center gap-2 ${
                    players.length >= 4
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  }`}
                >
                  <Play className="w-4 h-4" />
                  <span>Bắt Đầu Ván Ma Sói ({players.length}/8)</span>
                </button>
              </div>
            </div>
          )}

          {/* Active Gameplay Arena (Night / Day Discuss / Day Vote / Game Over) */}
          {phase !== 'lobby' && (
            <div className="space-y-4">
              {/* Interactive Player Grid */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-blue-400" />
                    Danh Sách Cư Dân Trong Làng ({players.filter((p) => p.isAlive).length}/{players.length} sống)
                  </span>
                  {phase === 'day_vote' && (
                    <span className="text-xs font-semibold text-red-400 animate-pulse">
                      ⚖️ Đang trong giờ biểu quyết treo cổ!
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {players.map((p) => {
                    const isTargetedByWolf = wolfVotes && wolfVotes[p.id];
                    const voteCount = dayVotes
                      ? Object.values(dayVotes).filter((v) => v === p.id).length
                      : 0;

                    const isMyVoteTarget = dayVotes && dayVotes[user.id] === p.id;
                    const canVoteThisPlayer =
                      phase === 'day_vote' && isAlive && p.isAlive && p.id !== user.id;

                    return (
                      <div
                        key={p.id}
                        className={`p-3.5 rounded-2xl border transition-all relative flex flex-col justify-between ${
                          !p.isAlive
                            ? 'bg-slate-950/70 border-slate-800/80 opacity-60'
                            : p.id === user.id
                            ? 'bg-blue-950/30 border-blue-500/50 shadow-md ring-1 ring-blue-500/30'
                            : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {/* Top: Avatar & Name */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <div
                              className="w-10 h-10 rounded-2xl flex items-center justify-center text-lg relative"
                              style={{ backgroundColor: `${p.color}30` }}
                            >
                              {p.avatar}
                              {!p.isAlive && (
                                <div className="absolute inset-0 bg-black/60 rounded-2xl flex items-center justify-center text-sm">
                                  💀
                                </div>
                              )}
                            </div>

                            {/* Status or Role Badge */}
                            <div className="text-right">
                              {p.revealedRole ? (
                                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                                  {p.revealedRole.toUpperCase()}
                                </span>
                              ) : p.isAlive ? (
                                <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                                  Còn sống
                                </span>
                              ) : (
                                <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-red-500/10 text-red-400 border border-red-500/30">
                                  Đã tử vong
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="font-bold text-xs text-slate-100 truncate flex items-center gap-1">
                            <span>{p.name}</span>
                            {p.id === user.id && (
                              <span className="text-[10px] text-blue-400">(Bạn)</span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {p.isBot ? 'Bot tự động' : 'Người chơi'}
                          </div>
                        </div>

                        {/* Middle: Indicators (Day Votes / Wolf Target) */}
                        <div className="my-2 space-y-1">
                          {voteCount > 0 && (
                            <div className="px-2 py-0.5 rounded-lg bg-red-950/50 border border-red-500/30 text-[11px] font-bold text-red-300 flex items-center justify-between">
                              <span>Số phiếu bầu:</span>
                              <span>{voteCount} 🗳️</span>
                            </div>
                          )}

                          {isTargetedByWolf && isWolf && (
                            <div className="px-2 py-0.5 rounded-lg bg-red-900/40 text-[10px] text-red-300 font-semibold">
                              🐺 Mục tiêu cắn
                            </div>
                          )}
                        </div>

                        {/* Bottom: Action Trigger during specific phases */}
                        {phase === 'day_vote' && isAlive && p.isAlive && (
                          <button
                            onClick={() => onAction('vote_lynch', p.id)}
                            className={`w-full py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 ${
                              isMyVoteTarget
                                ? 'bg-red-600 text-white'
                                : 'bg-slate-800 hover:bg-red-950/60 text-slate-300 hover:text-red-300 border border-slate-700'
                            }`}
                          >
                            <span>{isMyVoteTarget ? '✓ Đã chọn vote' : 'Bỏ phiếu treo'}</span>
                          </button>
                        )}

                        {phase === 'hunter_revenge' && myPlayer?.isHunterRevengePending && p.isAlive && (
                          <button
                            onClick={() => onAction('hunter_shot', p.id)}
                            className="w-full py-1.5 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-500 text-white transition flex items-center justify-center gap-1"
                          >
                            <span>🏹 Bắn người này</span>
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Night Specific Action Panel (for active role during sub-phase) */}
              {phase === 'night' && isAlive && (
                <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-4 shadow-xl">
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                      Hành Động Đêm Của Bạn (Vai Trò: {myRole?.toUpperCase()})
                    </span>
                  </div>

                  {/* Werewolf Action */}
                  {nightSubPhase === 'werewolf' && myRole === 'werewolf' && (
                    <div className="space-y-3">
                      <p className="text-xs text-slate-300">
                        Chọn một người chơi trong làng để cả bầy cùng cắn chết đêm nay:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {players
                          .filter((p) => p.isAlive && p.id !== user.id && p.role !== 'werewolf')
                          .map((target) => (
                            <button
                              key={target.id}
                              onClick={() => onAction('wolf_kill', target.id)}
                              className="px-3.5 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-200 text-xs font-bold transition flex items-center gap-1.5"
                            >
                              <span>🐺 Cắn {target.name}</span>
                            </button>
                          ))}
                      </div>
                    </div>
                  )}

                  {/* Seer Action */}
                  {nightSubPhase === 'seer' && myRole === 'seer' && (
                    <div className="space-y-3">
                      <p className="text-xs text-slate-300">
                        Chọn một người bạn muốn soi thấu linh hồn để biết người đó có phải Ma Sói không:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {players
                          .filter((p) => p.isAlive && p.id !== user.id)
                          .map((target) => (
                            <button
                              key={target.id}
                              onClick={() => onAction('seer_inspect', target.id)}
                              className="px-3.5 py-2 rounded-xl bg-purple-950/40 hover:bg-purple-900/60 border border-purple-500/40 text-purple-200 text-xs font-bold transition flex items-center gap-1.5"
                            >
                              <span>🔮 Soi {target.name}</span>
                            </button>
                          ))}
                      </div>
                    </div>
                  )}

                  {/* Bodyguard Action */}
                  {nightSubPhase === 'bodyguard' && myRole === 'bodyguard' && (
                    <div className="space-y-3">
                      <p className="text-xs text-slate-300">
                        Chọn một người để canh gác đêm nay (người này sẽ không bị Sói cắn chết):
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {players
                          .filter((p) => p.isAlive)
                          .map((target) => (
                            <button
                              key={target.id}
                              onClick={() => onAction('guard_protect', target.id)}
                              className="px-3.5 py-2 rounded-xl bg-blue-950/40 hover:bg-blue-900/60 border border-blue-500/40 text-blue-200 text-xs font-bold transition flex items-center gap-1.5"
                            >
                              <span>🛡️ Bảo vệ {target.name}</span>
                            </button>
                          ))}
                      </div>
                    </div>
                  )}

                  {/* Witch Action */}
                  {nightSubPhase === 'witch' && myRole === 'witch' && (
                    <div className="space-y-3">
                      <div className="text-xs text-slate-300 mb-1">
                        {nightPending?.victimId ? (
                          <span className="text-red-400 font-bold">
                            ⚠️ Đêm nay Sói đã tấn công:{' '}
                            {players.find((p) => p.id === nightPending?.victimId)?.name}!
                          </span>
                        ) : (
                          <span>Đêm nay Sói không tấn công được ai hoặc nạn nhân được bảo vệ.</span>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-3">
                        {witchPotions?.hasHeal && nightPending?.victimId && (
                          <button
                            onClick={() => onAction('witch_heal')}
                            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md"
                          >
                            <span>🧪 Dùng Bình Cứu Sống</span>
                          </button>
                        )}

                        {witchPotions?.hasPoison && (
                          <div className="w-full pt-1">
                            <span className="text-xs text-slate-400 block mb-1.5">
                              Hoặc chọn 1 người để hạ độc dược:
                            </span>
                            <div className="flex flex-wrap gap-2">
                              {players
                                .filter((p) => p.isAlive && p.id !== user.id)
                                .map((target) => (
                                  <button
                                    key={target.id}
                                    onClick={() => onAction('witch_poison', target.id)}
                                    className="px-3 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-200 text-xs font-semibold transition"
                                  >
                                    <span>☠️ Đầu độc {target.name}</span>
                                  </button>
                                ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Villager / Inactive subphase state */}
                  {!(
                    (nightSubPhase === 'werewolf' && myRole === 'werewolf') ||
                    (nightSubPhase === 'seer' && myRole === 'seer') ||
                    (nightSubPhase === 'bodyguard' && myRole === 'bodyguard') ||
                    (nightSubPhase === 'witch' && myRole === 'witch')
                  ) && (
                    <div className="text-center py-4 text-xs text-slate-400 space-y-1">
                      <div className="text-2xl">💤</div>
                      <p className="text-slate-300 font-medium">
                        Bạn đang ngủ say sưa trong căn nhà ấm cúng của mình...
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Hãy tĩnh tâm chờ đợi ánh bình minh chiếu rọi để cùng dân làng mở phiên luận tội!
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Game Over Victory Panel */}
              {phase === 'game_over' && (
                <div
                  className={`rounded-3xl p-6 border text-center space-y-4 shadow-2xl animate-in zoom-in-95 duration-300 ${
                    winner === 'werewolf'
                      ? 'bg-gradient-to-b from-red-950/60 to-slate-900 border-red-500/40'
                      : 'bg-gradient-to-b from-emerald-950/60 to-slate-900 border-emerald-500/40'
                  }`}
                >
                  <div className="text-5xl drop-shadow-md">
                    {winner === 'werewolf' ? '🐺' : '🏆'}
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white tracking-wide">
                      {winner === 'werewolf'
                        ? 'PHE MA SÓI THỐNG TRỊ LÀNG!'
                        : 'PHE DÂN LÀNG GIÀNH CHIẾN THẮNG!'}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
                      {winner === 'werewolf'
                        ? 'Ma Sói đã tiêu diệt gần hết dân làng và làm chủ hoàn toàn bóng đêm!'
                        : 'Mọi Ma Sói hiểm ác đã bị dân làng phát giác và đưa lên giàn thiêu!'}
                    </p>
                  </div>

                  {/* Revealed Roles List */}
                  <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 max-w-xl mx-auto text-left">
                    <div className="text-xs font-bold text-slate-300 mb-2">
                      Bảng Danh Tính Toàn Bộ Người Chơi:
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {players.map((p) => (
                        <div
                          key={p.id}
                          className="p-2 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs flex items-center gap-2"
                        >
                          <span className="text-base">{p.avatar}</span>
                          <div className="truncate">
                            <div className="font-bold text-slate-200 truncate">{p.name}</div>
                            <div className="text-[10px] text-amber-300 uppercase font-semibold">
                              {p.role}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <button
                      onClick={onResetGame}
                      className="px-8 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-900/30 transition"
                    >
                      Bắt Đầu Ván Đấu Mới
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Side: Multi-Channel Werewolf Chat & Logs */}
        <div className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-slate-800 bg-slate-900/60 backdrop-blur-md flex flex-col min-h-0 h-80 lg:h-auto">
          {/* Chat Channel Selector */}
          <div className="p-2 border-b border-slate-800 bg-slate-900/80 flex items-center gap-1 text-xs">
            <button
              onClick={() => setChatChannel('village')}
              className={`flex-1 py-1.5 px-2 rounded-xl font-semibold transition text-center ${
                chatChannel === 'village'
                  ? 'bg-slate-800 text-slate-100 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              💬 Làng Chung
            </button>

            {isWolf && (
              <button
                onClick={() => setChatChannel('wolf')}
                className={`flex-1 py-1.5 px-2 rounded-xl font-semibold transition text-center ${
                  chatChannel === 'wolf'
                    ? 'bg-red-950/60 text-red-300 border border-red-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🐺 Hang Sói
              </button>
            )}

            {!isAlive && phase !== 'lobby' && (
              <button
                onClick={() => setChatChannel('ghost')}
                className={`flex-1 py-1.5 px-2 rounded-xl font-semibold transition text-center ${
                  chatChannel === 'ghost'
                    ? 'bg-purple-950/60 text-purple-300 border border-purple-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                👻 Âm Giới
              </button>
            )}
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 text-xs">
            {filteredMessages.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-[11px]">
                Chưa có tin nhắn trong kênh này. Hãy gửi tin để trao đổi!
              </div>
            ) : (
              filteredMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-2.5 rounded-xl border leading-relaxed ${
                    msg.channel === 'narrator'
                      ? 'bg-amber-950/20 border-amber-500/30 text-amber-200 font-medium'
                      : msg.channel === 'wolf'
                      ? 'bg-red-950/25 border-red-500/30 text-red-200'
                      : msg.channel === 'ghost'
                      ? 'bg-purple-950/25 border-purple-500/30 text-purple-200'
                      : 'bg-slate-800/40 border-slate-700/60 text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 text-[10px] text-slate-400 mb-1">
                    <div className="flex items-center gap-1.5 font-bold">
                      <span>{msg.senderAvatar}</span>
                      <span className="text-slate-200">{msg.senderName}</span>
                      {msg.channel === 'wolf' && (
                        <span className="text-red-400 font-normal">[Sói mật]</span>
                      )}
                      {msg.channel === 'ghost' && (
                        <span className="text-purple-400 font-normal">[Hồn ma]</span>
                      )}
                    </div>
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div>{msg.content}</div>
                </div>
              ))
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Chat Input Bar */}
          <form
            onSubmit={handleSendChat}
            className="p-2 border-t border-slate-800 bg-slate-900/90 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder={
                chatChannel === 'wolf'
                  ? 'Bàn mưu trong hang sói bí mật...'
                  : chatChannel === 'ghost'
                  ? 'Trò chuyện cùng các hồn ma...'
                  : !isAlive && phase !== 'lobby'
                  ? 'Bạn đã chết, không thể chat kênh làng...'
                  : 'Nói chuyện cùng dân làng...'
              }
              value={chatInput}
              disabled={!isAlive && chatChannel === 'village' && phase !== 'lobby'}
              onChange={(e) => setChatInput(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-blue-500 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!chatInput.trim() || (!isAlive && chatChannel === 'village' && phase !== 'lobby')}
              className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white transition flex-shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Secret Role Card Modal */}
      <RoleCardModal
        isOpen={showRoleModal}
        onClose={() => setShowRoleModal(false)}
        role={myRole}
        faction={myFaction}
        isAlive={isAlive}
      />

      {/* Investigation Dossier Modal */}
      <InvestigationDossierModal
        isOpen={showDossierModal}
        onClose={() => setShowDossierModal(false)}
        players={players}
        logs={logs}
        seerHistory={seerHistory}
        roomId={room.id}
      />

      {/* Rules & Guide Modal */}
      <WerewolfRulesModal
        isOpen={showRulesModal}
        onClose={() => setShowRulesModal(false)}
      />
    </div>
  );
}
