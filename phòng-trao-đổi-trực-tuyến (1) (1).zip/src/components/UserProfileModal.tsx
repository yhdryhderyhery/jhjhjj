import React, { useState } from 'react';
import { X, Check, User, Sparkles } from 'lucide-react';
import type { UserProfile } from '../types';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
}

const AVATAR_OPTIONS = ['👨‍💻', '👩‍💻', '🦊', '🐱', '🐼', '🦁', '🦉', '🚀', '💡', '🌟', '🎨', '🔥', '☕', '⚡'];
const COLOR_OPTIONS = [
  '#3B82F6', // Blue
  '#10B981', // Emerald
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#F59E0B', // Amber
  '#06B6D4', // Cyan
  '#EF4444', // Red
  '#6366F1', // Indigo
];

export function UserProfileModal({
  isOpen,
  onClose,
  currentUser,
  onUpdateProfile,
}: UserProfileModalProps) {
  const [name, setName] = useState(currentUser.name);
  const [avatar, setAvatar] = useState(currentUser.avatar);
  const [color, setColor] = useState(currentUser.color);
  const [statusMessage, setStatusMessage] = useState(currentUser.statusMessage || '');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onUpdateProfile({
      name: name.trim(),
      avatar,
      color,
      statusMessage: statusMessage.trim(),
    });
    onClose();
  };

  const handleRandomize = () => {
    const randomAvatar = AVATAR_OPTIONS[Math.floor(Math.random() * AVATAR_OPTIONS.length)];
    const randomColor = COLOR_OPTIONS[Math.floor(Math.random() * COLOR_OPTIONS.length)];
    setAvatar(randomAvatar);
    setColor(randomColor);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-base font-bold text-slate-900 mb-1 flex items-center gap-2">
          <User className="w-5 h-5 text-blue-600" />
          Hồ Sơ & Biệt Danh Của Bạn
        </h3>
        <p className="text-xs text-slate-500 mb-5">
          Biệt danh và biểu tượng này sẽ hiển thị khi bạn nhắn tin và tham gia trao đổi.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Avatar Preview */}
          <div className="flex items-center justify-center gap-4 py-2">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center text-3xl shadow-md border-2 border-white ring-2 ring-slate-100 transition-transform hover:scale-105"
              style={{ backgroundColor: color }}
            >
              {avatar}
            </div>
            <button
              type="button"
              onClick={handleRandomize}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium px-3 py-1.5 bg-blue-50 hover:bg-blue-100 rounded-lg transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Ngẫu nhiên
            </button>
          </div>

          {/* Name input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Tên / Biệt danh hiển thị *
            </label>
            <input
              type="text"
              required
              maxLength={30}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="VD: Minh Tuấn, Lan Anh, Khách 482..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
            />
          </div>

          {/* Avatar Emoji Choice */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Chọn biểu tượng đại diện
            </label>
            <div className="grid grid-cols-7 gap-1.5">
              {AVATAR_OPTIONS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setAvatar(item)}
                  className={`p-2 text-xl rounded-xl border transition ${
                    avatar === item
                      ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {/* Color Choice */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Màu nền nhận diện
            </label>
            <div className="flex items-center gap-2">
              {COLOR_OPTIONS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className="w-8 h-8 rounded-full flex items-center justify-center transition border border-white hover:scale-110"
                  style={{ backgroundColor: c }}
                >
                  {color === c && <Check className="w-4 h-4 text-white" />}
                </button>
              ))}
            </div>
          </div>

          {/* Status Message */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Trạng thái / Giới thiệu ngắn
            </label>
            <input
              type="text"
              maxLength={60}
              value={statusMessage}
              onChange={(e) => setStatusMessage(e.target.value)}
              placeholder="VD: Sẵn sàng trao đổi 💬"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition"
            >
              Đóng
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition"
            >
              Lưu thay đổi
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
