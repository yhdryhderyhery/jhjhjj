import React from 'react';
import {
  MessageSquare,
  HelpCircle,
  Lightbulb,
  Coffee,
  Hash,
  Users,
  Share2,
  Volume2,
  VolumeX,
  PlusCircle,
  Sparkles,
  Moon,
} from 'lucide-react';
import type { Room, UserProfile } from '../types';

interface HeaderProps {
  currentRoom: Room;
  activeTab: 'chat' | 'werewolf' | 'topics' | 'polls';
  setActiveTab: (tab: 'chat' | 'werewolf' | 'topics' | 'polls') => void;
  onlineCount: number;
  onToggleOnlineList: () => void;
  isOnlineListOpen: boolean;
  onOpenShare: () => void;
  onOpenCreateTopic: () => void;
  onOpenCreatePoll: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  currentUser: UserProfile;
  onOpenProfile: () => void;
  onOpenMobileMenu: () => void;
}

export function Header({
  currentRoom,
  activeTab,
  setActiveTab,
  onlineCount,
  onToggleOnlineList,
  isOnlineListOpen,
  onOpenShare,
  onOpenCreateTopic,
  onOpenCreatePoll,
  soundEnabled,
  onToggleSound,
  currentUser,
  onOpenProfile,
  onOpenMobileMenu,
}: HeaderProps) {
  const getRoomIcon = (iconName: string) => {
    switch (iconName) {
      case 'moon':
        return <Moon className="w-5 h-5 text-purple-500" />;
      case 'help-circle':
        return <HelpCircle className="w-5 h-5 text-indigo-500" />;
      case 'lightbulb':
        return <Lightbulb className="w-5 h-5 text-amber-500" />;
      case 'coffee':
        return <Coffee className="w-5 h-5 text-emerald-500" />;
      case 'message-square':
        return <MessageSquare className="w-5 h-5 text-blue-500" />;
      default:
        return <Hash className="w-5 h-5 text-slate-500" />;
    }
  };

  return (
    <header className="border-b border-slate-200 bg-white/95 backdrop-blur sticky top-0 z-20 shadow-xs">
      <div className="h-16 px-4 flex items-center justify-between">
        {/* Left: Mobile Menu & Room Info */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            id="btn-mobile-menu"
            onClick={onOpenMobileMenu}
            className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
            aria-label="Mở danh sách phòng"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 bg-slate-100 rounded-lg flex-shrink-0">
              {getRoomIcon(currentRoom.icon)}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="font-semibold text-slate-800 truncate text-base leading-tight">
                  {currentRoom.name}
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/60 rounded-full flex-shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  {onlineCount} trực tuyến
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate hidden md:block max-w-md">
                {currentRoom.description}
              </p>
            </div>
          </div>
        </div>

        {/* Center: View Switcher Tabs (Desktop) */}
        <div className="hidden lg:flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200/80">
          <button
            id="tab-chat"
            onClick={() => setActiveTab('chat')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 ${
              activeTab === 'chat'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            Trò chuyện
          </button>
          <button
            id="tab-werewolf"
            onClick={() => setActiveTab('werewolf')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition flex items-center gap-1.5 ${
              activeTab === 'werewolf'
                ? 'bg-slate-900 text-amber-300 shadow-xs'
                : 'text-purple-700 hover:text-purple-900 bg-purple-50/60'
            }`}
          >
            <Moon className="w-3.5 h-3.5 text-purple-600" />
            Ma Sói 🐺
          </button>
          <button
            id="tab-topics"
            onClick={() => setActiveTab('topics')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 ${
              activeTab === 'topics'
                ? 'bg-white text-indigo-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5" />
            Chủ đề
          </button>
          <button
            id="tab-polls"
            onClick={() => setActiveTab('polls')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition flex items-center gap-1.5 ${
              activeTab === 'polls'
                ? 'bg-white text-pink-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Biểu quyết
          </button>
        </div>

        {/* Right: Quick actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick action button depending on tab */}
          {activeTab === 'topics' && (
            <button
              id="btn-header-new-topic"
              onClick={onOpenCreateTopic}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition shadow-xs"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              Đăng chủ đề
            </button>
          )}

          {activeTab === 'polls' && (
            <button
              id="btn-header-new-poll"
              onClick={onOpenCreatePoll}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-pink-600 hover:bg-pink-700 rounded-lg transition shadow-xs"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              Tạo biểu quyết
            </button>
          )}

          {/* Share / Invite Button */}
          <button
            id="btn-header-share"
            onClick={onOpenShare}
            title="Mời người khác vào phòng"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200/80 rounded-lg transition"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Mời vào phòng</span>
          </button>

          {/* Sound notification toggle */}
          <button
            id="btn-header-sound"
            onClick={onToggleSound}
            title={soundEnabled ? 'Tắt âm báo' : 'Bật âm báo'}
            className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
            aria-label="Bật tắt âm báo"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-slate-700" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>

          {/* Online users toggle */}
          <button
            id="btn-header-online-users"
            onClick={onToggleOnlineList}
            title="Danh sách người tham gia"
            className={`p-2 rounded-lg transition flex items-center gap-1 text-xs font-medium ${
              isOnlineListOpen
                ? 'bg-blue-100 text-blue-700'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
            aria-label="Hiển thị thành viên đang trực tuyến"
          >
            <Users className="w-4 h-4" />
            <span className="text-xs font-semibold">{onlineCount}</span>
          </button>

          {/* Current user profile pill */}
          <button
            id="btn-header-user-profile"
            onClick={onOpenProfile}
            className="flex items-center gap-2 pl-2 pr-2.5 py-1 text-left rounded-lg hover:bg-slate-100 border border-slate-200/60 transition"
            title="Chỉnh sửa hồ sơ / biệt danh"
          >
            <span
              className="w-7 h-7 rounded-full flex items-center justify-center text-sm shadow-2xs border border-white"
              style={{ backgroundColor: currentUser.color || '#3B82F6' }}
            >
              {currentUser.avatar || '👤'}
            </span>
            <div className="hidden xl:block leading-tight text-left">
              <div className="text-xs font-semibold text-slate-800 max-w-[100px] truncate">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-slate-500">Đổi biệt danh</div>
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Sub-header Tabs */}
      <div className="lg:hidden flex items-center justify-around border-t border-slate-200/80 bg-slate-50/80 px-2 py-1.5 text-xs">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex-1 py-1.5 px-2 rounded-lg text-center font-medium transition flex items-center justify-center gap-1 ${
            activeTab === 'chat' ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-600'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Chat</span>
        </button>
        <button
          onClick={() => setActiveTab('werewolf')}
          className={`flex-1 py-1.5 px-2 rounded-lg text-center font-bold transition flex items-center justify-center gap-1 ${
            activeTab === 'werewolf'
              ? 'bg-slate-900 text-amber-300 shadow-2xs'
              : 'text-purple-700'
          }`}
        >
          <Moon className="w-3.5 h-3.5" />
          <span>Ma Sói 🐺</span>
        </button>
        <button
          onClick={() => setActiveTab('topics')}
          className={`flex-1 py-1.5 px-2 rounded-lg text-center font-medium transition flex items-center justify-center gap-1 ${
            activeTab === 'topics' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-600'
          }`}
        >
          <Lightbulb className="w-3.5 h-3.5" />
          <span>Chủ đề</span>
        </button>
        <button
          onClick={() => setActiveTab('polls')}
          className={`flex-1 py-1.5 px-2 rounded-lg text-center font-medium transition flex items-center justify-center gap-1 ${
            activeTab === 'polls' ? 'bg-white text-pink-600 shadow-2xs' : 'text-slate-600'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Biểu quyết</span>
        </button>
      </div>
    </header>
  );
}

