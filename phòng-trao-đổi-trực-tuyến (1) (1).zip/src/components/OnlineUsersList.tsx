import React from 'react';
import { Users, X, Share2, ShieldCheck, UserCheck } from 'lucide-react';
import type { UserProfile } from '../types';

interface OnlineUsersListProps {
  isOpen: boolean;
  onClose: () => void;
  onlineUsers: UserProfile[];
  allOnlineUsers?: Array<{ user: UserProfile; roomId: string }>;
  currentUser: UserProfile;
  currentRoomId: string;
  roomName: string;
  onOpenShare: () => void;
  onSelectRoom?: (roomId: string) => void;
}

export function OnlineUsersList({
  isOpen,
  onClose,
  onlineUsers,
  allOnlineUsers = [],
  currentUser,
  currentRoomId,
  roomName,
  onOpenShare,
  onSelectRoom,
}: OnlineUsersListProps) {
  if (!isOpen) return null;

  // Filter users who are online in other rooms
  const otherRoomUsers = allOnlineUsers.filter(
    (item) => item.roomId !== currentRoomId && item.user.id !== currentUser.id
  );

  return (
    <>
      {/* Backdrop on mobile */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/20 backdrop-blur-xs z-30 lg:hidden"
      />

      <aside className="fixed lg:static inset-y-0 right-0 z-40 w-72 bg-white border-l border-slate-200 flex flex-col shadow-lg lg:shadow-none">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-500" />
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Người Dùng Trực Tuyến ({onlineUsers.length + otherRoomUsers.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
            title="Đóng danh sách"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Share Invite Card */}
        <div className="p-3 m-3 bg-blue-50/70 border border-blue-200/80 rounded-xl">
          <p className="text-[11px] text-blue-900 mb-2 leading-relaxed">
            Muốn trò chuyện cùng bạn bè? Gửi link phòng <b>#{roomName}</b> để họ tham gia ngay!
          </p>
          <button
            onClick={onOpenShare}
            className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Mời bạn bè</span>
          </button>
        </div>

        {/* Users List */}
        <div className="flex-1 overflow-y-auto px-3 py-1 space-y-3">
          {/* In current room */}
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1.5 flex items-center justify-between">
              <span>Trong phòng này (#{roomName})</span>
              <span className="text-emerald-600 font-semibold">{onlineUsers.length}</span>
            </div>

            <div className="space-y-1">
              {onlineUsers.map((user) => {
                const isMe = user.id === currentUser.id;

                return (
                  <div
                    key={user.id}
                    className={`flex items-center gap-2.5 p-2 rounded-xl transition ${
                      isMe ? 'bg-blue-50/50' : 'hover:bg-slate-50'
                    }`}
                  >
                    {/* Avatar with active green dot */}
                    <div className="relative flex-shrink-0">
                      <span
                        className="w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-2xs border border-white"
                        style={{ backgroundColor: user.color || '#3B82F6' }}
                      >
                        {user.avatar || '👤'}
                      </span>
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white"></span>
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-semibold text-slate-800 truncate">
                          {user.name}
                        </span>
                        {isMe && (
                          <span className="text-[10px] text-blue-600 font-medium bg-blue-100/70 px-1.5 py-0.2 rounded">
                            Bạn
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 truncate">
                        {user.statusMessage || 'Đang trực tuyến'}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* In other rooms */}
          {otherRoomUsers.length > 0 && (
            <div className="pt-2 border-t border-slate-100">
              <div className="text-[10px] font-bold text-amber-600 uppercase tracking-wider px-2 mb-1.5 flex items-center justify-between">
                <span>Ở phòng khác ({otherRoomUsers.length})</span>
              </div>

              <div className="space-y-1">
                {otherRoomUsers.map(({ user, roomId }) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between gap-2 p-2 rounded-xl bg-amber-50/40 border border-amber-100"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-7 h-7 rounded-full flex items-center justify-center text-xs shadow-2xs flex-shrink-0"
                        style={{ backgroundColor: user.color || '#F59E0B' }}
                      >
                        {user.avatar || '👤'}
                      </span>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-slate-800 truncate">
                          {user.name}
                        </div>
                        <div className="text-[10px] text-amber-700 truncate">
                          Phòng: {roomId}
                        </div>
                      </div>
                    </div>

                    {onSelectRoom && (
                      <button
                        onClick={() => {
                          onSelectRoom(roomId);
                          onClose();
                        }}
                        className="px-2 py-1 text-[10px] font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition flex-shrink-0"
                      >
                        Sang phòng
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-400">
          Cập nhật trạng thái tức thì
        </div>
      </aside>
    </>
  );
}
