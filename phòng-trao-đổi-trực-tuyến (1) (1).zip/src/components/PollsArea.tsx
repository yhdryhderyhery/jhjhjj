import React from 'react';
import {
  Sparkles,
  Plus,
  CheckCircle2,
  Users,
  Clock,
} from 'lucide-react';
import type { Poll, Room, UserProfile } from '../types';

interface PollsAreaProps {
  room: Room;
  polls: Poll[];
  currentUser: UserProfile;
  onOpenCreatePoll: () => void;
  onVotePoll: (pollId: string, optionId: string) => void;
}

export function PollsArea({
  room,
  polls,
  currentUser,
  onOpenCreatePoll,
  onVotePoll,
}: PollsAreaProps) {
  const formatTime = (timestamp: number) => {
    const d = new Date(timestamp);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')} - ${d.getDate()}/${d.getMonth() + 1}`;
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] bg-slate-50 overflow-hidden">
      {/* Header bar */}
      <div className="p-4 bg-white border-b border-slate-200 flex items-center justify-between gap-3 shadow-2xs">
        <div>
          <h2 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-pink-500" />
            Biểu Quyết & Khảo Sát Ý Kiến
          </h2>
          <p className="text-xs text-slate-500">
            Mọi thành viên trong phòng đều có thể tham gia bình chọn thời gian thực
          </p>
        </div>

        <button
          id="btn-new-poll"
          onClick={onOpenCreatePoll}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-pink-600 hover:bg-pink-700 text-white text-xs font-semibold rounded-lg shadow-xs transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Tạo biểu quyết mới</span>
        </button>
      </div>

      {/* Main Polls List */}
      <div className="flex-1 overflow-y-auto p-4 max-w-4xl w-full mx-auto space-y-4">
        {polls.length === 0 ? (
          <div className="py-16 text-center bg-white border border-slate-200 rounded-2xl p-8 max-w-md mx-auto shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-pink-50 text-pink-600 flex items-center justify-center mx-auto mb-3 text-xl">
              📊
            </div>
            <h3 className="font-semibold text-slate-800 text-sm mb-1">Chưa có biểu quyết nào</h3>
            <p className="text-xs text-slate-500 mb-4">
              Bạn có câu hỏi cần lấy ý kiến số đông? Hãy tạo biểu quyết để mọi người cùng chọn ngay!
            </p>
            <button
              onClick={onOpenCreatePoll}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-pink-600 text-white text-xs font-semibold rounded-lg hover:bg-pink-700 transition"
            >
              <Plus className="w-3.5 h-3.5" /> Mở biểu quyết ngay
            </button>
          </div>
        ) : (
          polls.map((poll) => {
            const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes.length, 0);
            const userVotedOption = poll.options.find((opt) => opt.votes.includes(currentUser.id));

            return (
              <div
                key={poll.id}
                id={`poll-card-${poll.id}`}
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs transition hover:border-slate-300"
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-pink-700 bg-pink-50 px-2 py-0.5 rounded-full border border-pink-200/60">
                        {poll.isActive ? 'Đang mở' : 'Đã kết thúc'}
                      </span>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {formatTime(poll.createdAt)}
                      </span>
                    </div>
                    <h3 className="text-sm sm:text-base font-semibold text-slate-900 leading-snug">
                      {poll.question}
                    </h3>
                  </div>

                  <div className="text-right flex-shrink-0">
                    <span className="inline-flex items-center gap-1 text-xs text-slate-500 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200/60">
                      <Users className="w-3 h-3 text-slate-400" />
                      <b>{totalVotes}</b> lượt vote
                    </span>
                  </div>
                </div>

                {/* Options List */}
                <div className="space-y-2.5 my-3">
                  {poll.options.map((option) => {
                    const voteCount = option.votes.length;
                    const percentage = totalVotes > 0 ? Math.round((voteCount / totalVotes) * 100) : 0;
                    const isSelected = option.votes.includes(currentUser.id);

                    return (
                      <button
                        key={option.id}
                        type="button"
                        onClick={() => onVotePoll(poll.id, option.id)}
                        className={`w-full relative text-left p-3 rounded-xl border transition overflow-hidden group ${
                          isSelected
                            ? 'border-pink-400 bg-pink-50/40 ring-1 ring-pink-300'
                            : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100/60 hover:border-slate-300'
                        }`}
                      >
                        {/* Fill percentage bar behind */}
                        <div
                          className={`absolute top-0 bottom-0 left-0 transition-all duration-300 pointer-events-none ${
                            isSelected ? 'bg-pink-100/70' : 'bg-slate-200/50'
                          }`}
                          style={{ width: `${percentage}%` }}
                        />

                        {/* Foreground content */}
                        <div className="relative z-10 flex items-center justify-between gap-3 text-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            <span
                              className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 text-[10px] ${
                                isSelected
                                  ? 'border-pink-600 bg-pink-600 text-white'
                                  : 'border-slate-300 bg-white group-hover:border-slate-400'
                              }`}
                            >
                              {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                            </span>
                            <span className={`font-medium truncate ${isSelected ? 'text-pink-900 font-semibold' : 'text-slate-800'}`}>
                              {option.text}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0 text-slate-500 font-semibold">
                            <span>{voteCount} phiếu</span>
                            <span className="text-[11px] text-slate-400">({percentage}%)</span>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Footer note */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                  <span>Tạo bởi: {poll.creatorName}</span>
                  {userVotedOption && (
                    <span className="text-pink-600 font-medium">
                      ✓ Bạn đã bình chọn cho: "{userVotedOption.text}"
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
