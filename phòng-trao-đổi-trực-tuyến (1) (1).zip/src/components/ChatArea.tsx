import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Pin,
  Smile,
  X,
  ChevronDown,
  Sparkles,
  MessageSquare,
  Flame,
  AlertCircle,
} from 'lucide-react';
import { MessageItem } from './MessageItem';
import type { Message, Room, TypingUser, UserProfile } from '../types';

interface ChatAreaProps {
  room: Room;
  messages: Message[];
  currentUser: UserProfile;
  typingUsers: TypingUser[];
  onSendMessage: (content: string, replyTo?: Message['replyTo']) => void;
  onToggleReaction: (messageId: string, emoji: string) => void;
  onTogglePin: (messageId: string) => void;
  onTyping: (isTyping: boolean) => void;
  onOpenCreatePoll: () => void;
  onOpenCreateTopic: () => void;
}

export function ChatArea({
  room,
  messages,
  currentUser,
  typingUsers,
  onSendMessage,
  onToggleReaction,
  onTogglePin,
  onTyping,
  onOpenCreatePoll,
  onOpenCreateTopic,
}: ChatAreaProps) {
  const [inputText, setInputText] = useState('');
  const [replyingMessage, setReplyingMessage] = useState<Message | null>(null);
  const [showPinnedBanner, setShowPinnedBanner] = useState(false);
  const [isScrolledUp, setIsScrolledUp] = useState(false);
  const [showQuickEmoji, setShowQuickEmoji] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const pinnedMessages = messages.filter((m) => m.isPinned);

  // Auto-scroll to bottom on new messages if not scrolled up
  useEffect(() => {
    if (!isScrolledUp) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isScrolledUp]);

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    setIsScrolledUp(distanceFromBottom > 120);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    setIsScrolledUp(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);

    // Typing notification throttled
    onTyping(true);
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    typingTimeoutRef.current = setTimeout(() => {
      onTyping(false);
    }, 2500);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    const text = inputText.trim();
    if (!text) return;

    const replyToPayload = replyingMessage
      ? {
          id: replyingMessage.id,
          senderName: replyingMessage.senderName,
          content: replyingMessage.content.slice(0, 100),
        }
      : undefined;

    onSendMessage(text, replyToPayload);
    setInputText('');
    setReplyingMessage(null);
    onTyping(false);

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    setTimeout(scrollToBottom, 50);
  };

  const handleInsertQuickPhrase = (phrase: string) => {
    setInputText((prev) => (prev ? `${prev} ${phrase}` : phrase));
  };

  // Filter typing users excluding oneself
  const activeOtherTyping = typingUsers.filter((u) => u.userId !== currentUser.id);

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] bg-slate-50 relative overflow-hidden">
      {/* Pinned Messages Header (if any) */}
      {pinnedMessages.length > 0 && (
        <div className="bg-amber-50/90 border-b border-amber-200/80 px-4 py-2 flex items-center justify-between text-xs text-amber-900 shadow-2xs z-10">
          <button
            onClick={() => setShowPinnedBanner(!showPinnedBanner)}
            className="flex items-center gap-2 font-medium hover:text-amber-950 transition flex-1 text-left truncate"
          >
            <Pin className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
            <span className="font-semibold">
              {pinnedMessages.length} tin nhắn đã ghim:
            </span>
            <span className="truncate text-amber-800 text-xs">
              {pinnedMessages[pinnedMessages.length - 1].content}
            </span>
          </button>
          <button
            onClick={() => setShowPinnedBanner(!showPinnedBanner)}
            className="text-[11px] font-semibold text-amber-800 hover:text-amber-950 px-2 py-0.5 rounded bg-amber-100/80 hover:bg-amber-200/80 transition ml-2 flex-shrink-0"
          >
            {showPinnedBanner ? 'Ẩn' : 'Xem tất cả'}
          </button>
        </div>
      )}

      {/* Expanded Pinned Messages Drawer */}
      {showPinnedBanner && pinnedMessages.length > 0 && (
        <div className="bg-amber-50/95 border-b border-amber-200 p-3 max-h-48 overflow-y-auto space-y-2 z-10 shadow-md">
          <div className="flex justify-between items-center text-xs font-semibold text-amber-900 mb-1">
            <span>Danh sách tin nhắn quan trọng trong phòng</span>
            <button
              onClick={() => setShowPinnedBanner(false)}
              className="p-1 hover:bg-amber-200/60 rounded text-amber-700"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          {pinnedMessages.map((msg) => (
            <div
              key={msg.id}
              className="bg-white/90 p-2.5 rounded-lg border border-amber-200/70 text-xs text-slate-800 flex items-start justify-between gap-2"
            >
              <div className="min-w-0">
                <span className="font-semibold text-slate-900 mr-2">{msg.senderName}:</span>
                <span className="text-slate-700">{msg.content}</span>
              </div>
              <button
                onClick={() => onTogglePin(msg.id)}
                className="text-[10px] text-amber-700 hover:underline flex-shrink-0"
              >
                Bỏ ghim
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Messages Stream Container */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-1"
      >
        {/* Room Welcome Card */}
        <div className="max-w-xl mx-auto my-6 p-5 bg-white border border-slate-200 rounded-2xl text-center shadow-xs">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3 text-xl shadow-2xs">
            💬
          </div>
          <h2 className="text-base font-bold text-slate-800 mb-1">
            Chào mừng bạn đến với {room.name}
          </h2>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-4 leading-relaxed">
            {room.description}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={() => handleInsertQuickPhrase('Xin chào mọi người! 👋')}
              className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-lg border border-slate-200 transition"
            >
              👋 Chào mọi người!
            </button>
            <button
              onClick={onOpenCreatePoll}
              className="px-3 py-1.5 bg-pink-50 hover:bg-pink-100 text-pink-700 text-xs font-medium rounded-lg border border-pink-200 transition flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3" /> Mở biểu quyết
            </button>
            <button
              onClick={onOpenCreateTopic}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-medium rounded-lg border border-indigo-200 transition flex items-center gap-1"
            >
              <MessageSquare className="w-3 h-3" /> Đăng chủ đề
            </button>
          </div>
        </div>

        {/* Message Items List */}
        {messages.map((message) => (
          <MessageItem
            key={message.id}
            message={message}
            currentUser={currentUser}
            onToggleReaction={onToggleReaction}
            onTogglePin={onTogglePin}
            onReplyTo={(msg) => setReplyingMessage(msg)}
          />
        ))}

        <div ref={messagesEndRef} />
      </div>

      {/* Floating Scroll-to-Bottom Button */}
      {isScrolledUp && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-24 right-6 bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-full shadow-lg text-xs font-medium flex items-center gap-1.5 transition z-10"
        >
          <span>Tin nhắn mới</span>
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
      )}

      {/* Typing Indicator Bar */}
      <div className="h-5 px-4 text-xs text-slate-500 italic flex items-center gap-2">
        {activeOtherTyping.length > 0 && (
          <span className="inline-flex items-center gap-1.5 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
            <span className="text-[11px] font-medium text-slate-600">
              {activeOtherTyping.length === 1
                ? `${activeOtherTyping[0].userName} đang nhập...`
                : `${activeOtherTyping[0].userName} và ${activeOtherTyping.length - 1} người khác đang nhập...`}
            </span>
          </span>
        )}
      </div>

      {/* Input Box Area */}
      <div className="p-3 sm:p-4 bg-white border-t border-slate-200/90 shadow-2xs">
        {/* Reply Preview Bar */}
        {replyingMessage && (
          <div className="mb-2 px-3 py-1.5 bg-blue-50/80 border border-blue-200 rounded-lg flex items-center justify-between text-xs text-blue-900">
            <div className="flex items-center gap-1.5 truncate">
              <span className="font-semibold text-blue-800">
                Đang trả lời {replyingMessage.senderName}:
              </span>
              <span className="truncate italic text-blue-700">
                "{replyingMessage.content}"
              </span>
            </div>
            <button
              onClick={() => setReplyingMessage(null)}
              className="p-1 hover:bg-blue-200/60 rounded text-blue-600 transition"
              title="Huỷ trả lời"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <div className="border border-slate-200 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 rounded-xl bg-slate-50/50 transition">
          <textarea
            id="chat-input-textarea"
            rows={2}
            value={inputText}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder={`Nhắn tin vào #${room.name}... (Nhấn Enter để gửi, Shift+Enter để xuống dòng)`}
            className="w-full px-3.5 py-2.5 bg-transparent resize-none text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden leading-relaxed"
          />

          <div className="px-3 py-2 border-t border-slate-100 flex items-center justify-between">
            {/* Quick emoji and tools */}
            <div className="flex items-center gap-1">
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowQuickEmoji(!showQuickEmoji)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition"
                  title="Chèn biểu cảm"
                >
                  <Smile className="w-4 h-4" />
                </button>

                {showQuickEmoji && (
                  <div className="absolute left-0 bottom-full mb-2 bg-white border border-slate-200 rounded-xl p-2 shadow-lg grid grid-cols-6 gap-1 z-30 w-52">
                    {['👍', '❤️', '🔥', '💡', '🎉', '😊', '😂', '👏', '🚀', '✨', '🤝', '☕'].map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => {
                          handleInsertQuickPhrase(emoji);
                          setShowQuickEmoji(false);
                        }}
                        className="p-1.5 text-base hover:bg-slate-100 rounded-lg transition text-center"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Quick Poll Button */}
              <button
                type="button"
                onClick={onOpenCreatePoll}
                className="hidden sm:inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-pink-700 bg-pink-50 hover:bg-pink-100 rounded-md transition"
                title="Tạo biểu quyết ý kiến"
              >
                <Sparkles className="w-3 h-3" />
                <span>Biểu quyết</span>
              </button>

              {/* Quick Topic Button */}
              <button
                type="button"
                onClick={onOpenCreateTopic}
                className="hidden sm:inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-md transition"
                title="Đăng chủ đề thảo luận mới"
              >
                <MessageSquare className="w-3 h-3" />
                <span>Chủ đề</span>
              </button>
            </div>

            {/* Send Button */}
            <button
              id="btn-send-message"
              type="button"
              disabled={!inputText.trim()}
              onClick={handleSend}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:hover:bg-blue-600 text-white text-xs font-semibold rounded-lg shadow-xs transition"
            >
              <span>Gửi</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
