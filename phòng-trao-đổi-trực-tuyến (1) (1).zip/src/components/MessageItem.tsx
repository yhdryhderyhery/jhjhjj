import React, { useState } from 'react';
import {
  Pin,
  Reply,
  Smile,
  Check,
} from 'lucide-react';
import type { Message, UserProfile } from '../types';

interface MessageItemProps {
  key?: React.Key;
  message: Message;
  currentUser: UserProfile;
  onToggleReaction: (messageId: string, emoji: string) => void;
  onTogglePin: (messageId: string) => void;
  onReplyTo: (message: Message) => void;
}

const POPULAR_EMOJIS = ['👍', '❤️', '💡', '🔥', '😂', '👏', '🎉', '🚀'];

export function MessageItem({
  message,
  currentUser,
  onToggleReaction,
  onTogglePin,
  onReplyTo,
}: MessageItemProps) {
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const isOwnMessage = message.senderId === currentUser.id;
  const isSystem = message.type === 'announcement' || message.type === 'system';

  const formatTime = (timestamp: number) => {
    const d = new Date(timestamp);
    const hours = d.getHours().toString().padStart(2, '0');
    const minutes = d.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  // Convert raw links to clickable anchor tags
  const renderFormattedText = (text: string) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = text.split(urlRegex);

    return parts.map((part, i) => {
      if (part.match(urlRegex)) {
        return (
          <a
            key={i}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 underline hover:text-blue-800 break-all font-medium"
          >
            {part}
          </a>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  if (isSystem) {
    return (
      <div className="my-3 px-4 py-2.5 bg-gradient-to-r from-blue-50/70 via-indigo-50/70 to-slate-50 border border-blue-100 rounded-xl text-xs text-slate-700 flex items-start gap-2.5 shadow-2xs">
        <span className="text-base flex-shrink-0">{message.senderAvatar || '📢'}</span>
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-slate-900 flex items-center gap-1.5 mb-0.5">
            {message.senderName}
            <span className="text-[10px] text-slate-400 font-normal">
              {formatTime(message.timestamp)}
            </span>
            {message.isPinned && (
              <span className="inline-flex items-center gap-0.5 text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">
                <Pin className="w-2.5 h-2.5" /> Ghim
              </span>
            )}
          </div>
          <div className="text-slate-600 leading-relaxed break-words whitespace-pre-wrap">
            {renderFormattedText(message.content)}
          </div>
        </div>

        {/* Reaction button */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => onToggleReaction(message.id, '👍')}
            className="p-1 hover:bg-white/80 rounded text-slate-400 hover:text-slate-700 transition"
            title="Thả biểu cảm"
          >
            <Smile className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      id={`message-${message.id}`}
      className={`group relative flex gap-3 py-2 px-3 sm:px-4 rounded-xl transition hover:bg-slate-100/60 ${
        message.isPinned ? 'bg-amber-50/40 border-l-2 border-amber-400' : ''
      }`}
    >
      {/* Sender Avatar */}
      <div
        className="w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-2xs border border-white flex-shrink-0 mt-0.5 select-none"
        style={{ backgroundColor: message.senderColor || '#3B82F6' }}
      >
        {message.senderAvatar || '👤'}
      </div>

      {/* Message Body */}
      <div className="min-w-0 flex-1">
        {/* Header line */}
        <div className="flex items-baseline gap-2 mb-0.5">
          <span className={`text-xs font-semibold ${isOwnMessage ? 'text-blue-700' : 'text-slate-800'}`}>
            {message.senderName}
            {isOwnMessage && <span className="text-[10px] font-normal text-slate-400 ml-1">(Bạn)</span>}
          </span>
          <span className="text-[10px] text-slate-400">{formatTime(message.timestamp)}</span>

          {message.isPinned && (
            <span className="inline-flex items-center gap-0.5 text-[10px] font-medium bg-amber-50 text-amber-700 px-1.5 py-0.2 rounded border border-amber-200/60">
              <Pin className="w-2.5 h-2.5" /> Đã ghim
            </span>
          )}
        </div>

        {/* Quoted Reply Preview */}
        {message.replyTo && (
          <div className="mb-1.5 text-xs bg-slate-100/90 border-l-2 border-blue-500 rounded-r-md px-2.5 py-1 text-slate-600 max-w-lg">
            <span className="font-semibold text-slate-700 mr-1.5">
              Trả lời {message.replyTo.senderName}:
            </span>
            <span className="italic truncate inline-block max-w-xs align-bottom">
              {message.replyTo.content}
            </span>
          </div>
        )}

        {/* Message Content */}
        <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap break-words">
          {renderFormattedText(message.content)}
        </div>

        {/* Reactions List */}
        {message.reactions && Object.keys(message.reactions).length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {Object.entries(message.reactions).map(([emoji, users]) => {
              if (!users || users.length === 0) return null;
              const hasReacted = users.includes(currentUser.id);

              return (
                <button
                  key={emoji}
                  onClick={() => onToggleReaction(message.id, emoji)}
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border transition ${
                    hasReacted
                      ? 'bg-blue-50 border-blue-300 text-blue-700'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                  title={`${users.length} người đã thả ${emoji}`}
                >
                  <span>{emoji}</span>
                  <span className="text-[11px] font-semibold">{users.length}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Action Menu on Hover */}
      <div className="absolute right-3 top-2 hidden group-hover:flex items-center gap-1 bg-white border border-slate-200/90 rounded-lg p-1 shadow-sm z-10">
        {/* Quick Emojis */}
        <div className="flex items-center gap-0.5 pr-1 border-r border-slate-100">
          {POPULAR_EMOJIS.slice(0, 4).map((emoji) => {
            const hasReacted = message.reactions?.[emoji]?.includes(currentUser.id);
            return (
              <button
                key={emoji}
                onClick={() => onToggleReaction(message.id, emoji)}
                className={`p-1 text-xs hover:bg-slate-100 rounded transition ${
                  hasReacted ? 'bg-blue-50 text-blue-600' : ''
                }`}
                title={`Thả ${emoji}`}
              >
                {emoji}
              </button>
            );
          })}

          <div className="relative">
            <button
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition"
              title="Xem thêm biểu cảm"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>

            {showEmojiPicker && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl p-2 shadow-lg grid grid-cols-4 gap-1 z-20 w-36">
                {POPULAR_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      onToggleReaction(message.id, emoji);
                      setShowEmojiPicker(false);
                    }}
                    className="p-1.5 text-base hover:bg-slate-100 rounded-lg text-center transition"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Reply Action */}
        <button
          onClick={() => onReplyTo(message)}
          className="p-1 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded transition"
          title="Trả lời trích dẫn"
        >
          <Reply className="w-3.5 h-3.5" />
        </button>

        {/* Pin Action */}
        <button
          onClick={() => onTogglePin(message.id)}
          className={`p-1 rounded transition ${
            message.isPinned
              ? 'text-amber-600 bg-amber-50 hover:bg-amber-100'
              : 'text-slate-500 hover:text-amber-600 hover:bg-slate-100'
          }`}
          title={message.isPinned ? 'Bỏ ghim tin nhắn' : 'Ghim tin nhắn'}
        >
          <Pin className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
