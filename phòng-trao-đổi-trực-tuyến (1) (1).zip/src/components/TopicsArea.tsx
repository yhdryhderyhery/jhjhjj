import React, { useState } from 'react';
import {
  Lightbulb,
  Plus,
  ThumbsUp,
  MessageCircle,
  Tag,
  Search,
  Send,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import type { Room, Topic, TopicComment, UserProfile } from '../types';

interface TopicsAreaProps {
  room: Room;
  topics: Topic[];
  currentUser: UserProfile;
  onOpenCreateTopic: () => void;
  onVoteTopic: (topicId: string) => void;
  onAddComment: (topicId: string, content: string) => void;
  commentsByTopic: Record<string, TopicComment[]>;
  onLoadComments: (topicId: string) => void;
}

export function TopicsArea({
  room,
  topics,
  currentUser,
  onOpenCreateTopic,
  onVoteTopic,
  onAddComment,
  commentsByTopic,
  onLoadComments,
}: TopicsAreaProps) {
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // Extract all tags from topics
  const allTags = Array.from(new Set(topics.flatMap((t) => t.tags || [])));

  const filteredTopics = topics.filter((topic) => {
    const matchesSearch =
      topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      topic.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = selectedTag ? topic.tags?.includes(selectedTag) : true;
    return matchesSearch && matchesTag;
  });

  const selectedTopic = topics.find((t) => t.id === selectedTopicId);
  const currentComments = selectedTopicId ? commentsByTopic[selectedTopicId] || [] : [];

  const handleSelectTopic = (topicId: string) => {
    if (selectedTopicId === topicId) {
      setSelectedTopicId(null);
    } else {
      setSelectedTopicId(topicId);
      onLoadComments(topicId);
    }
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !selectedTopicId) return;
    onAddComment(selectedTopicId, commentInput.trim());
    setCommentInput('');
  };

  const formatTime = (timestamp: number) => {
    const d = new Date(timestamp);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')} - ${d.getDate()}/${d.getMonth() + 1}`;
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] bg-slate-50 overflow-hidden">
      {/* Top filter and actions header */}
      <div className="p-4 bg-white border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Tìm kiếm chủ đề hoặc câu hỏi..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 hover:bg-slate-100/80 focus:bg-white text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {selectedTag && (
            <button
              onClick={() => setSelectedTag(null)}
              className="text-xs text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg hover:bg-indigo-100 transition"
            >
              Thẻ: #{selectedTag} ✕
            </button>
          )}

          <button
            id="btn-new-topic"
            onClick={onOpenCreateTopic}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Đăng chủ đề mới</span>
          </button>
        </div>
      </div>

      {/* Tags Pill Carousel */}
      {allTags.length > 0 && (
        <div className="px-4 py-2 bg-white/70 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto text-xs">
          <span className="text-slate-400 text-[11px] font-medium mr-1 flex items-center gap-1">
            <Tag className="w-3 h-3" /> Thẻ:
          </span>
          <button
            onClick={() => setSelectedTag(null)}
            className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium transition ${
              selectedTag === null
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Tất cả
          </button>
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag === selectedTag ? null : tag)}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium transition ${
                selectedTag === tag
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              #{tag}
            </button>
          ))}
        </div>
      )}

      {/* Main Container: Topics List + Detail Drawer */}
      <div className="flex-1 overflow-y-auto p-4 max-w-5xl w-full mx-auto space-y-3">
        {filteredTopics.length === 0 ? (
          <div className="py-16 text-center bg-white border border-slate-200 rounded-2xl p-8 max-w-md mx-auto shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3 text-xl">
              💡
            </div>
            <h3 className="font-semibold text-slate-800 text-sm mb-1">Chưa có chủ đề nào</h3>
            <p className="text-xs text-slate-500 mb-4">
              Hãy là người đầu tiên đưa ra câu hỏi hoặc chủ đề để mọi người trong phòng cùng trao đổi!
            </p>
            <button
              onClick={onOpenCreateTopic}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition"
            >
              <Plus className="w-3.5 h-3.5" /> Đăng chủ đề ngay
            </button>
          </div>
        ) : (
          filteredTopics.map((topic) => {
            const hasUpvoted = topic.upvotes?.includes(currentUser.id);
            const isExpanded = selectedTopicId === topic.id;

            return (
              <div
                key={topic.id}
                className={`bg-white border rounded-2xl transition shadow-xs overflow-hidden ${
                  isExpanded ? 'border-indigo-300 ring-1 ring-indigo-200' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="p-4 sm:p-5 flex items-start gap-4">
                  {/* Upvote column */}
                  <button
                    onClick={() => onVoteTopic(topic.id)}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl border transition flex-shrink-0 w-12 ${
                      hasUpvoted
                        ? 'bg-indigo-50 border-indigo-200 text-indigo-600 font-semibold'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                    title={hasUpvoted ? 'Bỏ thích' : 'Ủng hộ chủ đề này'}
                  >
                    <ThumbsUp className="w-4 h-4 mb-0.5" />
                    <span className="text-xs">{topic.upvotes?.length || 0}</span>
                  </button>

                  {/* Content column */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      {topic.isSolved && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" /> Đã giải quyết
                        </span>
                      )}
                      <h3
                        onClick={() => handleSelectTopic(topic.id)}
                        className="text-sm font-semibold text-slate-900 hover:text-indigo-600 cursor-pointer transition leading-snug"
                      >
                        {topic.title}
                      </h3>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">
                      {topic.content}
                    </p>

                    {/* Metadata Footer */}
                    <div className="flex items-center justify-between gap-3 text-xs text-slate-500 pt-2 border-t border-slate-100 flex-wrap">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] text-white"
                          style={{ backgroundColor: topic.authorColor || '#8B5CF6' }}
                        >
                          {topic.authorAvatar || '👤'}
                        </span>
                        <span className="font-medium text-slate-700">{topic.authorName}</span>
                        <span className="text-slate-400 text-[11px]">• {formatTime(topic.createdAt)}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        {topic.tags?.map((t) => (
                          <span
                            key={t}
                            className="bg-slate-100 text-slate-600 text-[10px] font-medium px-2 py-0.5 rounded-md"
                          >
                            #{t}
                          </span>
                        ))}

                        <button
                          onClick={() => handleSelectTopic(topic.id)}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 bg-indigo-50/80 hover:bg-indigo-100/80 px-2.5 py-1 rounded-lg transition"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>{topic.commentsCount || 0} ý kiến</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Expandable Comments Drawer */}
                {isExpanded && (
                  <div className="bg-slate-50/80 border-t border-slate-200 p-4 sm:p-5 space-y-4">
                    <div className="font-semibold text-xs text-slate-700 flex items-center gap-1.5">
                      <MessageCircle className="w-4 h-4 text-indigo-500" />
                      <span>Các ý kiến trao đổi ({currentComments.length})</span>
                    </div>

                    {/* Comments list */}
                    <div className="space-y-2.5">
                      {currentComments.length === 0 ? (
                        <div className="text-xs text-slate-400 italic py-2">
                          Chưa có phản hồi nào. Hãy chia sẻ góc nhìn của bạn bên dưới!
                        </div>
                      ) : (
                        currentComments.map((cmt) => (
                          <div
                            key={cmt.id}
                            className="bg-white p-3 rounded-xl border border-slate-200/80 text-xs shadow-2xs"
                          >
                            <div className="flex items-center justify-between gap-2 mb-1.5">
                              <div className="flex items-center gap-2">
                                <span
                                  className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] text-white"
                                  style={{ backgroundColor: cmt.authorColor || '#3B82F6' }}
                                >
                                  {cmt.authorAvatar || '👤'}
                                </span>
                                <span className="font-semibold text-slate-800">
                                  {cmt.authorName}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-400">
                                {formatTime(cmt.createdAt)}
                              </span>
                            </div>
                            <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">
                              {cmt.content}
                            </p>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Comment Input */}
                    <form onSubmit={handleSendComment} className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Viết ý kiến thảo luận của bạn..."
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        className="flex-1 px-3 py-2 bg-white text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                      />
                      <button
                        type="submit"
                        disabled={!commentInput.trim()}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold rounded-xl shadow-xs transition flex items-center gap-1"
                      >
                        <span>Gửi</span>
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
