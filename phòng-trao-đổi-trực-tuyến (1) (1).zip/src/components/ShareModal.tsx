import React, { useState } from 'react';
import { X, Copy, Check, Share2, Smartphone, Monitor, Globe } from 'lucide-react';
import type { Room } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  room: Room;
}

export function ShareModal({ isOpen, onClose, room }: ShareModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?room=${room.id}`
    : `https://...?room=${room.id}`;

  const handleCopy = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(currentUrl);
      } else {
        const input = document.createElement('input');
        input.value = currentUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
          <Share2 className="w-6 h-6" />
        </div>

        <h3 className="text-base font-bold text-slate-900 mb-1">
          Mời Người Khác Vào Phòng Trao Đổi
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Bất kỳ ai có liên kết này đều có thể vào phòng <b>#{room.name}</b> để nhắn tin, biểu quyết và thảo luận cùng bạn ngay tức thì.
        </p>

        {/* Copy Link Input Box */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Đường dẫn vào phòng
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={currentUrl}
              className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 select-all focus:outline-hidden"
            />
            <button
              id="btn-copy-share-url"
              onClick={handleCopy}
              className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition flex items-center gap-1.5 flex-shrink-0 shadow-xs ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Đã chép!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Sao chép</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Multi-device guide banner */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-2 text-xs text-slate-600 mb-5">
          <div className="font-semibold text-slate-800 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-blue-500" />
            Cách thức hoạt động nhiều người:
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-600">
            <Monitor className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
            <span>Mở thêm tab ẩn danh (Incognito) hoặc trình duyệt khác để thử nghiệm 2 người trao đổi song song.</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-600">
            <Smartphone className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
            <span>Gửi liên kết qua Zalo, Messenger hoặc Email cho bạn bè, họ bấm vào là vào thẳng phòng.</span>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}
