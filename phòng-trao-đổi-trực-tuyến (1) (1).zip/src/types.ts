export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  color: string;
  statusMessage?: string;
  joinedAt: number;
}

export interface MessageReaction {
  emoji: string;
  users: string[]; // userIds
}

export interface Message {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderColor: string;
  content: string;
  timestamp: number;
  replyTo?: {
    id: string;
    senderName: string;
    content: string;
  };
  reactions: Record<string, string[]>; // emoji -> array of userIds
  isPinned?: boolean;
  type?: 'text' | 'system' | 'announcement';
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // userIds who voted
}

export interface Poll {
  id: string;
  roomId: string;
  question: string;
  creatorId: string;
  creatorName: string;
  createdAt: number;
  options: PollOption[];
  isActive: boolean;
}

export interface TopicComment {
  id: string;
  topicId: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorColor: string;
  content: string;
  createdAt: number;
  upvotes: string[]; // userIds
}

export interface Topic {
  id: string;
  roomId: string;
  title: string;
  content: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorColor: string;
  createdAt: number;
  tags: string[];
  upvotes: string[]; // userIds
  commentsCount: number;
  isSolved?: boolean;
}

export interface Room {
  id: string;
  name: string;
  description: string;
  icon: string;
  isDefault?: boolean;
  createdAt: number;
}

export interface TypingUser {
  userId: string;
  userName: string;
  roomId: string;
  timestamp: number;
}

export * from './werewolfTypes';
import type {
  ClientWerewolfSync,
  WerewolfChatMessage,
  WerewolfRole,
} from './werewolfTypes';

export interface RoomStateSync {
  room: Room;
  messages: Message[];
  polls: Poll[];
  topics: Topic[];
  onlineUsers: UserProfile[];
  allOnlineUsers?: Array<{ user: UserProfile; roomId: string }>;
  allCounts?: Record<string, number>;
  werewolfState?: ClientWerewolfSync;
  werewolfMessages?: WerewolfChatMessage[];
}

export type WsMessage =
  | { type: 'join'; payload: { user: UserProfile; roomId: string } }
  | { type: 'leave'; payload: { userId: string; roomId: string } }
  | { type: 'send_message'; payload: { roomId: string; content: string; replyTo?: Message['replyTo'] } }
  | { type: 'new_message'; payload: Message }
  | { type: 'toggle_reaction'; payload: { messageId: string; emoji: string; roomId: string } }
  | { type: 'reaction_updated'; payload: { messageId: string; reactions: Record<string, string[]> } }
  | { type: 'toggle_pin'; payload: { messageId: string; roomId: string } }
  | { type: 'pin_updated'; payload: { messageId: string; isPinned: boolean } }
  | { type: 'typing'; payload: { roomId: string; isTyping: boolean } }
  | { type: 'typing_update'; payload: { typingUsers: TypingUser[]; roomId: string } }
  | { type: 'create_poll'; payload: { roomId: string; question: string; options: string[] } }
  | { type: 'new_poll'; payload: Poll }
  | { type: 'vote_poll'; payload: { pollId: string; optionId: string; roomId: string } }
  | { type: 'poll_updated'; payload: Poll }
  | { type: 'create_topic'; payload: { roomId: string; title: string; content: string; tags: string[] } }
  | { type: 'new_topic'; payload: Topic }
  | { type: 'vote_topic'; payload: { topicId: string; roomId: string } }
  | { type: 'topic_updated'; payload: Topic }
  | { type: 'add_comment'; payload: { topicId: string; content: string; roomId: string } }
  | { type: 'comment_added'; payload: { comment: TopicComment; topicId: string } }
  | { type: 'sync_state'; payload: RoomStateSync }
  | { type: 'presence_update'; payload: { roomId: string; users: UserProfile[]; allOnline?: Array<{ user: UserProfile; roomId: string }>; allCounts?: Record<string, number> } }
  | { type: 'rooms_list'; payload: Room[] }
  | { type: 'create_room'; payload: { name: string; description: string; icon: string } }
  // Werewolf messages
  | { type: 'werewolf_start'; payload: { roomId: string } }
  | { type: 'werewolf_reset'; payload: { roomId: string } }
  | { type: 'werewolf_add_bots'; payload: { roomId: string; count?: number } }
  | { type: 'werewolf_join_seat'; payload: { roomId: string } }
  | { type: 'werewolf_leave_seat'; payload: { roomId: string } }
  | { type: 'werewolf_action'; payload: { roomId: string; action: 'wolf_kill' | 'seer_check' | 'guard_protect' | 'witch_save' | 'witch_poison' | 'hunter_shoot' | 'day_vote'; targetId?: string } }
  | { type: 'werewolf_send_chat'; payload: { roomId: string; content: string; channel: 'village' | 'wolf' | 'ghost' } }
  | { type: 'werewolf_sync'; payload: ClientWerewolfSync }
  | { type: 'werewolf_new_chat'; payload: WerewolfChatMessage }
  | { type: 'werewolf_next_phase'; payload: { roomId: string } };

