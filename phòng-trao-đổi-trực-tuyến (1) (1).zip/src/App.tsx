import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { TopicsArea } from './components/TopicsArea';
import { PollsArea } from './components/PollsArea';
import { WerewolfArea } from './components/werewolf/WerewolfArea';
import { OnlineUsersList } from './components/OnlineUsersList';
import { UserProfileModal } from './components/UserProfileModal';
import { CreateRoomModal } from './components/CreateRoomModal';
import { CreatePollModal } from './components/CreatePollModal';
import { CreateTopicModal } from './components/CreateTopicModal';
import { ShareModal } from './components/ShareModal';
import { playMessageChime } from './utils/audio';
import type {
  Message,
  Poll,
  Room,
  Topic,
  TopicComment,
  TypingUser,
  UserProfile,
  WsMessage,
  WerewolfClientSyncPayload,
  WerewolfChatMessage,
  WerewolfActionType,
} from './types';

const DEFAULT_ROOMS: Room[] = [
  {
    id: 'chung',
    name: 'Trao Đổi Chung',
    description: 'Nơi mọi người tự do chào hỏi, trao đổi thông tin và kết nối trực tuyến.',
    icon: 'message-square',
    isDefault: true,
    createdAt: Date.now(),
  },
  {
    id: 'ma-soi',
    name: 'Làng Ma Sói Đêm Trăng',
    description: 'Đấu trí Ma Sói thời gian thực: phân vai bí mật, bỏ phiếu ban ngày, kỹ năng ban đêm và sổ tay điều tra.',
    icon: 'moon',
    isDefault: true,
    createdAt: Date.now(),
  },
  {
    id: 'thao-luan',
    name: 'Diễn Đàn Thảo Luận',
    description: 'Chủ đề chuyên sâu, hỏi đáp kinh nghiệm, chia sẻ kiến thức hữu ích.',
    icon: 'help-circle',
    isDefault: true,
    createdAt: Date.now(),
  },
  {
    id: 'y-tuong',
    name: 'Góc Ý Tưởng & Dự Án',
    description: 'Cùng nhau đóng góp ý tưởng, nhận xét giải pháp và tìm đồng đội hợp tác.',
    icon: 'lightbulb',
    isDefault: true,
    createdAt: Date.now(),
  },
  {
    id: 'giai-tri',
    name: 'Góc Thư Giãn',
    description: 'Tâm sự chuyện thường ngày, âm nhạc, sở thích và giải trí.',
    icon: 'coffee',
    isDefault: true,
    createdAt: Date.now(),
  },
];

const DEFAULT_AVATARS = ['👨‍💻', '👩‍💻', '🦊', '🐱', '🐼', '🦁', '🚀', '🎨', '💡', '🌟'];
const DEFAULT_COLORS = ['#3B82F6', '#10B981', '#8B5CF6', '#EC4899', '#F59E0B', '#06B6D4'];

function getInitialUser(): UserProfile {
  if (typeof window !== 'undefined') {
    const sessionCached = sessionStorage.getItem('exchange_hub_user');
    if (sessionCached) {
      try {
        return JSON.parse(sessionCached);
      } catch {
        // Fallback
      }
    }
  }

  const randNum = Math.floor(100 + Math.random() * 900);
  const randAvatar = DEFAULT_AVATARS[Math.floor(Math.random() * DEFAULT_AVATARS.length)];
  const randColor = DEFAULT_COLORS[Math.floor(Math.random() * DEFAULT_COLORS.length)];

  let preferredName = `Thành viên ${randNum}`;
  let preferredAvatar = randAvatar;
  let preferredColor = randColor;

  if (typeof window !== 'undefined') {
    try {
      const pref = localStorage.getItem('exchange_hub_pref');
      if (pref) {
        const parsed = JSON.parse(pref);
        if (parsed.avatar) preferredAvatar = parsed.avatar;
        if (parsed.color) preferredColor = parsed.color;
      }
    } catch {
      // Fallback
    }
  }

  const newUser: UserProfile = {
    id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name: preferredName,
    avatar: preferredAvatar,
    color: preferredColor,
    statusMessage: 'Sẵn sàng trao đổi 💬',
    joinedAt: Date.now(),
  };

  if (typeof window !== 'undefined') {
    sessionStorage.setItem('exchange_hub_user', JSON.stringify(newUser));
  }
  return newUser;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile>(getInitialUser);
  const [rooms, setRooms] = useState<Room[]>(DEFAULT_ROOMS);
  const [currentRoomId, setCurrentRoomId] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlRoom = params.get('room');
      if (urlRoom) return urlRoom;
    }
    return 'chung';
  });

  const [activeTab, setActiveTab] = useState<'chat' | 'werewolf' | 'topics' | 'polls'>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('room') === 'ma-soi') return 'werewolf';
    }
    return 'chat';
  });
  const [werewolfState, setWerewolfState] = useState<WerewolfClientSyncPayload | null>(null);
  const [werewolfMessages, setWerewolfMessages] = useState<WerewolfChatMessage[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [polls, setPolls] = useState<Poll[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<UserProfile[]>([]);
  const [allOnlineUsers, setAllOnlineUsers] = useState<Array<{ user: UserProfile; roomId: string }>>([]);
  const [onlineCountsByRoom, setOnlineCountsByRoom] = useState<Record<string, number>>({});
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([]);
  const [commentsByTopic, setCommentsByTopic] = useState<Record<string, TopicComment[]>>({});
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('exchange_hub_sound') !== 'false';
    }
    return true;
  });

  // Modals & Drawers state
  const [isOnlineListOpen, setIsOnlineListOpen] = useState(false);
  const [isOpenMobile, setIsOpenMobile] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isCreateRoomModalOpen, setIsCreateRoomModalOpen] = useState(false);
  const [isCreatePollModalOpen, setIsCreatePollModalOpen] = useState(false);
  const [isCreateTopicModalOpen, setIsCreateTopicModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const currentRoom = rooms.find((r) => r.id === currentRoomId) || rooms[0] || DEFAULT_ROOMS[0];

  const handleSelectRoom = (roomId: string) => {
    setCurrentRoomId(roomId);
    setTypingUsers([]);
    if (roomId === 'ma-soi') {
      setActiveTab('werewolf');
    } else if (activeTab === 'werewolf') {
      setActiveTab('chat');
    }
  };

  // Fetch rooms list and initial online counts on mount
  useEffect(() => {
    fetch('/api/rooms')
      .then((res) => res.json())
      .then((data) => {
        if (data.rooms && Array.isArray(data.rooms)) {
          setRooms(data.rooms);
        }
        if (data.onlineCounts) {
          setOnlineCountsByRoom(data.onlineCounts);
        }
      })
      .catch((err) => console.error('Error fetching rooms:', err));
  }, []);

  // Connect WebSocket & Join Room
  const connectWebSocket = useCallback(() => {
    if (socketRef.current) {
      try {
        socketRef.current.close();
      } catch {
        // ignore
      }
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      // Send join message
      const joinMsg: WsMessage = {
        type: 'join',
        payload: {
          user: currentUser,
          roomId: currentRoomId,
        },
      };
      ws.send(JSON.stringify(joinMsg));
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data) as WsMessage;
        switch (msg.type) {
          case 'sync_state': {
            const { messages, polls, topics, onlineUsers, allOnlineUsers: allOnline, allCounts, werewolfState, werewolfMessages } = msg.payload;
            setMessages(messages || []);
            setPolls(polls || []);
            setTopics(topics || []);
            setOnlineUsers(onlineUsers || []);
            if (allOnline) setAllOnlineUsers(allOnline);
            if (allCounts) setOnlineCountsByRoom(allCounts);
            if (werewolfState) setWerewolfState(werewolfState);
            if (werewolfMessages) setWerewolfMessages(werewolfMessages);
            break;
          }

          case 'new_message': {
            const newMsg = msg.payload;
            setMessages((prev) => {
              if (prev.some((m) => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });

            // Play sound chime if from another user
            if (soundEnabled && newMsg.senderId !== currentUser.id) {
              playMessageChime();
            }
            break;
          }

          case 'reaction_updated': {
            const { messageId, reactions } = msg.payload;
            setMessages((prev) =>
              prev.map((m) => (m.id === messageId ? { ...m, reactions } : m))
            );
            break;
          }

          case 'pin_updated': {
            const { messageId, isPinned } = msg.payload;
            setMessages((prev) =>
              prev.map((m) => (m.id === messageId ? { ...m, isPinned } : m))
            );
            break;
          }

          case 'typing_update': {
            const { typingUsers } = msg.payload;
            setTypingUsers(typingUsers || []);
            break;
          }

          case 'new_poll': {
            const newPoll = msg.payload;
            setPolls((prev) => {
              if (prev.some((p) => p.id === newPoll.id)) return prev;
              return [newPoll, ...prev];
            });
            break;
          }

          case 'poll_updated': {
            const updatedPoll = msg.payload;
            setPolls((prev) =>
              prev.map((p) => (p.id === updatedPoll.id ? updatedPoll : p))
            );
            break;
          }

          case 'new_topic': {
            const newTopic = msg.payload;
            setTopics((prev) => {
              if (prev.some((t) => t.id === newTopic.id)) return prev;
              return [newTopic, ...prev];
            });
            break;
          }

          case 'topic_updated': {
            const updatedTopic = msg.payload;
            setTopics((prev) =>
              prev.map((t) => (t.id === updatedTopic.id ? updatedTopic : t))
            );
            break;
          }

          case 'comment_added': {
            const { comment, topicId } = msg.payload;
            setCommentsByTopic((prev) => ({
              ...prev,
              [topicId]: [...(prev[topicId] || []), comment],
            }));
            break;
          }

          case 'presence_update': {
            const { users, allOnline, allCounts } = msg.payload;
            if (users) setOnlineUsers(users);
            if (allOnline) setAllOnlineUsers(allOnline);
            if (allCounts) setOnlineCountsByRoom(allCounts);
            break;
          }

          case 'rooms_list': {
            setRooms(msg.payload || []);
            break;
          }

          case 'werewolf_sync': {
            setWerewolfState(msg.payload);
            break;
          }

          case 'werewolf_new_chat': {
            setWerewolfMessages((prev) => [...prev, msg.payload]);
            break;
          }

          default:
            break;
        }
      } catch (err) {
        console.error('Error parsing WS message:', err);
      }
    };

    ws.onclose = () => {
      // Auto-reconnect with safe delay
      reconnectTimeoutRef.current = setTimeout(() => {
        connectWebSocket();
      }, 3000);
    };

    ws.onerror = (err) => {
      // Avoid calling console.error which triggers AI Studio error detection
      console.warn('WebSocket connection state notice:', (err as any)?.type || 'connecting');
    };
  }, [currentUser, currentRoomId, soundEnabled]);

  // Direct HTTP state hydration for immediate loading & offline/proxy resilience
  const fetchRoomState = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        userColor: currentUser.color,
      });
      const res = await fetch(`/api/rooms/${currentRoomId}/state?${params.toString()}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.messages) setMessages(data.messages);
      if (data.polls) setPolls(data.polls);
      if (data.topics) setTopics(data.topics);
      if (data.onlineUsers) setOnlineUsers(data.onlineUsers);
      if (data.allOnlineUsers) setAllOnlineUsers(data.allOnlineUsers);
      if (data.allCounts) setOnlineCountsByRoom(data.allCounts);
      if (data.werewolfState) setWerewolfState(data.werewolfState);
      if (data.werewolfMessages) setWerewolfMessages(data.werewolfMessages);
    } catch {
      // Graceful ignore
    }
  }, [currentRoomId, currentUser.id, currentUser.name, currentUser.avatar, currentUser.color]);

  useEffect(() => {
    connectWebSocket();
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [connectWebSocket]);

  // Background fallback sync if WebSocket is reconnecting or proxy drops upgrade
  useEffect(() => {
    fetchRoomState();
    const interval = setInterval(() => {
      if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
        fetchRoomState();
      }
    }, 2500);
    return () => clearInterval(interval);
  }, [fetchRoomState]);

  // Unified message sender supporting both WebSocket and HTTP fallback
  const sendWsMessage = useCallback(
    (msg: WsMessage) => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify(msg));
      } else {
        // Transparent HTTP fallback
        fetch('/api/ws-fallback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...msg,
            payload: {
              ...(msg.payload || {}),
              user: currentUser,
              roomId: currentRoomId,
            },
          }),
        })
          .then(() => fetchRoomState())
          .catch(() => {});
      }
    },
    [currentUser, currentRoomId, fetchRoomState]
  );

  // Actions
  const handleSendMessage = (content: string, replyTo?: Message['replyTo']) => {
    sendWsMessage({
      type: 'send_message',
      payload: {
        roomId: currentRoomId,
        content,
        replyTo,
      },
    });
  };

  const handleToggleReaction = (messageId: string, emoji: string) => {
    sendWsMessage({
      type: 'toggle_reaction',
      payload: {
        messageId,
        emoji,
        roomId: currentRoomId,
      },
    });
  };

  const handleTogglePin = (messageId: string) => {
    sendWsMessage({
      type: 'toggle_pin',
      payload: {
        messageId,
        roomId: currentRoomId,
      },
    });
  };

  const handleTyping = (isTyping: boolean) => {
    sendWsMessage({
      type: 'typing',
      payload: {
        roomId: currentRoomId,
        isTyping,
      },
    });
  };

  const handleCreatePoll = (question: string, options: string[]) => {
    sendWsMessage({
      type: 'create_poll',
      payload: {
        roomId: currentRoomId,
        question,
        options,
      },
    });
    setActiveTab('polls');
  };

  const handleVotePoll = (pollId: string, optionId: string) => {
    sendWsMessage({
      type: 'vote_poll',
      payload: {
        pollId,
        optionId,
        roomId: currentRoomId,
      },
    });
  };

  const handleCreateTopic = (title: string, content: string, tags: string[]) => {
    sendWsMessage({
      type: 'create_topic',
      payload: {
        roomId: currentRoomId,
        title,
        content,
        tags,
      },
    });
    setActiveTab('topics');
  };

  const handleVoteTopic = (topicId: string) => {
    sendWsMessage({
      type: 'vote_topic',
      payload: {
        topicId,
        roomId: currentRoomId,
      },
    });
  };

  const handleAddComment = (topicId: string, content: string) => {
    sendWsMessage({
      type: 'add_comment',
      payload: {
        topicId,
        content,
        roomId: currentRoomId,
      },
    });
  };

  const handleLoadComments = (topicId: string) => {
    if (commentsByTopic[topicId]) return;
    fetch(`/api/topics/${topicId}/comments`)
      .then((res) => res.json())
      .then((data) => {
        if (data.comments) {
          setCommentsByTopic((prev) => ({
            ...prev,
            [topicId]: data.comments,
          }));
        }
      })
      .catch((err) => console.error('Error fetching comments:', err));
  };

  const handleCreateRoom = (name: string, description: string, icon: string) => {
    fetch('/api/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description, icon }),
    })
      .then((res) => res.json())
      .then((newRoom) => {
        if (newRoom && newRoom.id) {
          setRooms((prev) => [...prev, newRoom]);
          setCurrentRoomId(newRoom.id);
        }
      })
      .catch((err) => console.error('Error creating room:', err));
  };

  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
    const nextUser = { ...currentUser, ...updated };
    setCurrentUser(nextUser);
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('exchange_hub_user', JSON.stringify(nextUser));
      localStorage.setItem(
        'exchange_hub_pref',
        JSON.stringify({
          name: nextUser.name,
          avatar: nextUser.avatar,
          color: nextUser.color,
        })
      );
    }

    // Notify server of updated user info
    sendWsMessage({
      type: 'join',
      payload: {
        user: nextUser,
        roomId: currentRoomId,
      },
    });
  };

  const handleToggleSound = () => {
    setSoundEnabled((prev) => {
      const next = !prev;
      localStorage.setItem('exchange_hub_sound', next.toString());
      return next;
    });
  };

  // Werewolf Game Action Handlers
  const handleWerewolfJoinSeat = (seatIndex?: number) => {
    sendWsMessage({
      type: 'werewolf_join_seat',
      payload: { roomId: currentRoomId, seatIndex },
    });
  };

  const handleWerewolfLeaveSeat = () => {
    sendWsMessage({
      type: 'werewolf_leave_seat',
      payload: { roomId: currentRoomId },
    });
  };

  const handleWerewolfAddBots = (count: number) => {
    sendWsMessage({
      type: 'werewolf_add_bots',
      payload: { roomId: currentRoomId, count },
    });
  };

  const handleWerewolfStart = () => {
    sendWsMessage({
      type: 'werewolf_start',
      payload: { roomId: currentRoomId },
    });
  };

  const handleWerewolfReset = () => {
    sendWsMessage({
      type: 'werewolf_reset',
      payload: { roomId: currentRoomId },
    });
  };

  const handleWerewolfAction = (action: WerewolfActionType, targetId?: string) => {
    sendWsMessage({
      type: 'werewolf_action',
      payload: { roomId: currentRoomId, action, targetId },
    });
  };

  const handleWerewolfSendChat = (content: string, channel: 'village' | 'wolf' | 'ghost') => {
    sendWsMessage({
      type: 'werewolf_send_chat',
      payload: { roomId: currentRoomId, content, channel },
    });
  };

  const handleWerewolfNextPhase = () => {
    sendWsMessage({
      type: 'werewolf_next_phase',
      payload: { roomId: currentRoomId },
    });
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 font-sans overflow-hidden select-text">
      {/* Sidebar for Room Channels */}
      <Sidebar
        rooms={rooms}
        currentRoomId={currentRoomId}
        onSelectRoom={handleSelectRoom}
        onOpenCreateRoom={() => setIsCreateRoomModalOpen(true)}
        currentUser={currentUser}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        isOpenMobile={isOpenMobile}
        onCloseMobile={() => setIsOpenMobile(false)}
        onlineCountByRoom={onlineCountsByRoom}
      />

      {/* Main Workspace */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Header Navigation */}
        <Header
          currentRoom={currentRoom}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onlineCount={onlineUsers.length}
          onToggleOnlineList={() => setIsOnlineListOpen((prev) => !prev)}
          isOnlineListOpen={isOnlineListOpen}
          onOpenShare={() => setIsShareModalOpen(true)}
          onOpenCreateTopic={() => setIsCreateTopicModalOpen(true)}
          onOpenCreatePoll={() => setIsCreatePollModalOpen(true)}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          currentUser={currentUser}
          onOpenProfile={() => setIsProfileModalOpen(true)}
          onOpenMobileMenu={() => setIsOpenMobile(true)}
        />

        {/* Content Views */}
        <main className="flex-1 flex min-w-0 overflow-hidden relative">
          {activeTab === 'chat' && (
            <ChatArea
              room={currentRoom}
              messages={messages}
              currentUser={currentUser}
              typingUsers={typingUsers}
              onSendMessage={handleSendMessage}
              onToggleReaction={handleToggleReaction}
              onTogglePin={handleTogglePin}
              onTyping={handleTyping}
              onOpenCreatePoll={() => setIsCreatePollModalOpen(true)}
              onOpenCreateTopic={() => setIsCreateTopicModalOpen(true)}
            />
          )}

          {activeTab === 'werewolf' && (
            <WerewolfArea
              room={currentRoom}
              user={currentUser}
              gameState={werewolfState}
              chatMessages={werewolfMessages}
              onJoinSeat={() => handleWerewolfJoinSeat()}
              onLeaveSeat={handleWerewolfLeaveSeat}
              onAddBots={handleWerewolfAddBots}
              onStartGame={handleWerewolfStart}
              onResetGame={handleWerewolfReset}
              onAction={handleWerewolfAction}
              onSendChat={handleWerewolfSendChat}
              onNextPhase={handleWerewolfNextPhase}
            />
          )}

          {activeTab === 'topics' && (
            <TopicsArea
              room={currentRoom}
              topics={topics}
              currentUser={currentUser}
              onOpenCreateTopic={() => setIsCreateTopicModalOpen(true)}
              onVoteTopic={handleVoteTopic}
              onAddComment={handleAddComment}
              commentsByTopic={commentsByTopic}
              onLoadComments={handleLoadComments}
            />
          )}

          {activeTab === 'polls' && (
            <PollsArea
              room={currentRoom}
              polls={polls}
              currentUser={currentUser}
              onOpenCreatePoll={() => setIsCreatePollModalOpen(true)}
              onVotePoll={handleVotePoll}
            />
          )}

          {/* Online Participants List Drawer */}
          <OnlineUsersList
            isOpen={isOnlineListOpen}
            onClose={() => setIsOnlineListOpen(false)}
            onlineUsers={onlineUsers}
            allOnlineUsers={allOnlineUsers}
            currentUser={currentUser}
            currentRoomId={currentRoomId}
            onOpenShare={() => setIsShareModalOpen(true)}
            roomName={currentRoom.name}
            onSelectRoom={handleSelectRoom}
          />
        </main>
      </div>

      {/* Modals */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        onUpdateProfile={handleUpdateProfile}
      />

      <CreateRoomModal
        isOpen={isCreateRoomModalOpen}
        onClose={() => setIsCreateRoomModalOpen(false)}
        onCreateRoom={handleCreateRoom}
      />

      <CreatePollModal
        isOpen={isCreatePollModalOpen}
        onClose={() => setIsCreatePollModalOpen(false)}
        onCreatePoll={handleCreatePoll}
      />

      <CreateTopicModal
        isOpen={isCreateTopicModalOpen}
        onClose={() => setIsCreateTopicModalOpen(false)}
        onCreateTopic={handleCreateTopic}
      />

      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        room={currentRoom}
      />
    </div>
  );
}
